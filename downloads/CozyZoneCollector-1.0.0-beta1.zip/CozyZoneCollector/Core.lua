-- Zone Collector: namespace, saved variables, provider selection, slash commands.
--
-- Every file receives the same private addon table via `...`, so nothing
-- except the SavedVariables table (ZoneCollectorDB), the slash command
-- registration and the main frame's name (needed for Escape-to-close)
-- touches the global namespace.

local addonName, ZC = ...

ZC.name = addonName
ZC.Data = ZC.Data or {}
ZC.UI = ZC.UI or {}
ZC.Providers = ZC.Providers or {}
ZC.Sources = ZC.Sources or {}

function ZC:Print(message)
    print("|cffffd100Cozy Zone Collector:|r " .. tostring(message))
end

local function InitDatabase()
    if type(ZoneCollectorDB) ~= "table" then
        ZoneCollectorDB = {}
    end
    ZC.db = ZoneCollectorDB
    ZC.db.characters = ZC.db.characters or {}
end

-- Per-character records the game won't give us on demand (e.g. known
-- flight paths), keyed by character GUID so alts never mix.
function ZC:GetCharacterDB()
    local guid = UnitGUID("player") or "unknown"
    local characters = self.db.characters
    local record = characters[guid]
    if not record then
        record = {}
        characters[guid] = record
    end
    record.name = record.name or UnitName("player")
    record.knownFlightPaths = record.knownFlightPaths or {}
    record.knownRecipes = record.knownRecipes or {}
    return record
end

-- Whether totals only include what the logged-in character can do.
function ZC:IsEligibleOnly()
    local value = self.db and self.db.eligibleOnly
    if value == nil then
        return self.Config.DefaultEligibleOnly
    end
    return value
end

function ZC:SetEligibleOnly(enabled)
    self.db.eligibleOnly = enabled and true or false
end

-- Whether the window follows the player into each new zone.
function ZC:IsAutoSwitchZone()
    return self.db and self.db.autoSwitchZone and true or false
end

function ZC:SetAutoSwitchZone(enabled)
    self.db.autoSwitchZone = enabled and true or false
end

-- Which "not counted" reasons are hidden from the item lists.
function ZC:GetHiddenReasons()
    if self.db and self.db.hiddenReasons then
        return self.db.hiddenReasons
    end
    local defaults = {}
    for reason, hidden in pairs(self.Config.DefaultHiddenReasons) do
        defaults[reason] = hidden
    end
    if self.db then
        self.db.hiddenReasons = defaults
    end
    return defaults
end

function ZC:SetReasonHidden(reason, hidden)
    self:GetHiddenReasons()[reason] = hidden and true or nil
end

-- The one place that decides which provider is live. Retail is the
-- default; "/zc mock" switches to development data for UI work.
-- (ForeverProvider will be chosen here once we can detect that client.)
function ZC:SelectProvider()
    local provider = self.db.useMock and self.Providers.Mock or self.Providers.Retail
    self:SetProvider(provider)
    provider:Activate()
end

-- Providers call this when game state changes. Bursts of events are
-- folded into one refresh.
local refreshPending = false
function ZC:NotifyDataChanged()
    if refreshPending then
        return
    end
    refreshPending = true
    C_Timer.After(0.5, function()
        refreshPending = false
        ZC.UI.MainFrame:RefreshIfShown()
    end)
end

-- Names/icons finished loading: redraw lists without recounting anything.
local redrawPending = false
function ZC:NotifyDisplayChanged()
    if redrawPending then
        return
    end
    redrawPending = true
    C_Timer.After(0.2, function()
        redrawPending = false
        ZC.UI.MainFrame:RedrawLists()
    end)
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:SetScript("OnEvent", function(self, event, loadedName)
    if event == "ADDON_LOADED" and loadedName == addonName then
        InitDatabase()
        ZC:SelectProvider()
        self:UnregisterEvent("ADDON_LOADED")
    end
end)

local function HandleSlashCommand(input)
    local command = strtrim(input or ""):lower()
    local mainFrame = ZC.UI.MainFrame

    if command == "reset" then
        mainFrame:ResetPosition()
        ZC:Print("Window position reset.")
    elseif command == "mock" then
        ZC.db.useMock = not ZC.db.useMock
        ZC:SelectProvider()
        mainFrame:RefreshIfShown()
        ZC:Print(ZC.db.useMock and "Showing development mock data." or "Showing real data.")
    elseif command == "macro" then
        mainFrame:PickupMacro()
    elseif command == "help" then
        ZC:Print("/zc - toggle the window")
        ZC:Print("/zc reset - reset the window position")
        ZC:Print("/zc macro - put a one-click macro on your cursor for an action bar")
        ZC:Print("/zc mock - switch between real data and development mock data")
    else
        mainFrame:Toggle()
    end
end

SLASH_ZONECOLLECTOR1 = "/zc"
SLASH_ZONECOLLECTOR2 = "/zonecollector"
SlashCmdList["ZONECOLLECTOR"] = HandleSlashCommand
