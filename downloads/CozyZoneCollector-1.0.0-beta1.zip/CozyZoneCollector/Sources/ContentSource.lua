-- ContentSource: what exists in each zone, from the bundled data file
-- Data/ZoneContent.lua (extracted once from AllTheThings by
-- Tools/extract_att.lua - ATT does not need to be installed or running).
--
-- For each zone it returns lists of entries
-- { id, reason, questID, coords, itemID, name, source }
-- where `reason` is nil when the logged-in character can do the thing,
-- otherwise why not (keys of ZC.Config.ExclusionReasons). Completion is
-- checked elsewhere (Providers/RetailProvider.lua) with Blizzard APIs.

local _, ZC = ...

local ContentSource = {}
ZC.Sources.Content = ContentSource

local LIST_NAMES = {
    "quests", "achievements", "flightPaths", "exploration", "transmog",
    "pets", "decor", "rares", "treasures", "recipes",
}

-- When an entry has several reasons, the most permanent one is reported.
local REASON_PRIORITY = {
    "removed", "untrackable", "repeatable", "faction", "class", "race", "profession", "holiday", "breadcrumb",
}

-- Lists whose entries can only be counted with a hidden quest flag / map points.
local NEEDS_QUEST_FLAG = { rares = true, treasures = true }
local NEEDS_POINTS = { exploration = true }

local FACTION_IDS = { Horde = 1, Alliance = 2 }

local evaluatedCache = {}

--------------------------------------------------------------------------------
-- Player
--------------------------------------------------------------------------------

-- GetProfessions returns fixed slots (primary 1, primary 2, archaeology,
-- fishing, cooking) and any of them can be nil, so walk every slot.
local function GetPlayerProfessions()
    local skillLines = {}
    local slots = { GetProfessions() }
    for slot = 1, select("#", GetProfessions()) do
        local index = slots[slot]
        if index then
            local skillLine = select(7, GetProfessionInfo(index))
            if skillLine then
                skillLines[skillLine] = true
            end
        end
    end
    return skillLines
end

local function GetPlayerInfo()
    local _, _, classID = UnitClass("player")
    local _, _, raceID = UnitRace("player")
    local factionID = FACTION_IDS[UnitFactionGroup("player")]
    local factionKey = factionID == 1 and "H" or "A"
    return {
        classID = classID, raceID = raceID, factionID = factionID, factionKey = factionKey,
        professions = GetPlayerProfessions(),
    }
end

--------------------------------------------------------------------------------
-- Raw data
--------------------------------------------------------------------------------

-- Zones are stored as text and unpacked the first time they're needed.
local function GetRawZone(zoneID)
    local zones = ZC.Data.ZoneContent
    local raw = zones and zones[zoneID]
    if type(raw) == "string" then
        local chunk = loadstring("return " .. raw)
        raw = chunk and chunk() or nil
        zones[zoneID] = raw
    end
    return raw
end

-- A zone includes its sub-zones (Elwynn Forest -> Northshire).
local function CollectZoneTree(zoneID, into, visited)
    if visited[zoneID] then
        return
    end
    visited[zoneID] = true
    local raw = GetRawZone(zoneID)
    if not raw then
        return
    end
    into[#into + 1] = raw
    for _, childID in ipairs(raw.children or {}) do
        CollectZoneTree(childID, into, visited)
    end
end

--------------------------------------------------------------------------------
-- Evaluation
--------------------------------------------------------------------------------

local function Contains(list, value)
    for _, item in ipairs(list) do
        if item == value then
            return true
        end
    end
    return false
end

-- Faction-specific overrides use `false` to mean "no restriction".
local function Field(entry, override, key)
    if override and override[key] ~= nil then
        return override[key] or nil
    end
    return entry[key]
end

local function GetReason(listName, entry, player)
    if type(entry) ~= "table" then
        return nil -- a bare ID: no restrictions
    end
    local override = entry[player.factionKey]
    local reasons = {}

    if Field(entry, override, "rm") then reasons.removed = true end
    if Field(entry, override, "ev") then reasons.holiday = true end
    local faction = Field(entry, override, "r")
    if faction and faction ~= player.factionID then reasons.faction = true end
    local classes = Field(entry, override, "c")
    if classes and not Contains(classes, player.classID) then reasons.class = true end
    local races = Field(entry, override, "ra")
    if races and not Contains(races, player.raceID) then reasons.race = true end
    if entry.rs and not player.professions[entry.rs] then reasons.profession = true end
    if entry.bc then reasons.breadcrumb = true end
    if entry.rep then reasons.repeatable = true end

    for _, reason in ipairs(REASON_PRIORITY) do
        if reasons[reason] then
            return reason
        end
    end
end

local function EvaluateEntry(listName, entry, player)
    local id = type(entry) == "table" and entry[1] or entry
    local result = {
        id = id,
        reason = GetReason(listName, entry, player),
        questID = type(entry) == "table" and entry.q or nil,
        coords = type(entry) == "table" and entry.xy or nil,
        itemID = type(entry) == "table" and entry.it or nil,
        name = type(entry) == "table" and entry.n or nil,
        source = type(entry) == "table" and entry.src or nil,
    }
    if not result.reason then
        if NEEDS_QUEST_FLAG[listName] and not result.questID then
            result.reason = "untrackable" -- e.g. old rares the game never flags as killed
        elseif NEEDS_POINTS[listName] and not result.coords then
            result.reason = "untrackable" -- no map points known to check against
        end
    end
    return result
end

-- The same thing can be listed in a zone and a sub-zone; keep the most
-- favourable version (doable beats any reason).
local function AddEvaluated(list, index, evaluated)
    local position = index[evaluated.id]
    if position then
        if not evaluated.reason then
            list[position] = evaluated
        end
        return
    end
    list[#list + 1] = evaluated
    index[evaluated.id] = #list
end

--------------------------------------------------------------------------------
-- Public
--------------------------------------------------------------------------------

function ContentSource:HasData()
    return type(ZC.Data.ZoneContent) == "table"
end

function ContentSource:GetVersion()
    return ZC.Data.ContentSourceVersion
end

-- Results depend on the character (class, race, faction, professions);
-- call when any of those change.
function ContentSource:InvalidateCache()
    wipe(evaluatedCache)
end

function ContentSource:GetZoneContent(zoneID)
    if evaluatedCache[zoneID] then
        return evaluatedCache[zoneID]
    end

    local rawZones = {}
    CollectZoneTree(zoneID, rawZones, {})
    if #rawZones == 0 then
        return nil
    end

    local player = GetPlayerInfo()
    local content = {}
    for _, listName in ipairs(LIST_NAMES) do
        local list, index = {}, {}
        for _, raw in ipairs(rawZones) do
            for _, entry in ipairs(raw[listName] or {}) do
                AddEvaluated(list, index, EvaluateEntry(listName, entry, player))
            end
        end
        content[listName] = list
    end

    evaluatedCache[zoneID] = content
    return content
end
