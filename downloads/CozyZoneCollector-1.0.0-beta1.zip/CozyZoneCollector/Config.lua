-- Static configuration: window sizing and the ordered list of tracked
-- categories. Keys here are the contract between providers and the UI;
-- labels and icons are presentation only.

local _, ZC = ...

ZC.Config = {
    Window = {
        width = 960,
        height = 580,
        sidebarWidth = 220,
        summaryWidth = 230,
    },

    -- Display order of zone categories. A provider returns progress keyed
    -- by `key`; the UI walks this list so order never depends on table
    -- iteration.
    --
    -- `clients` limits a category to specific game clients ("retail",
    -- "forever"). Omitted means every client. Providers filter on this, so
    -- the UI never checks which client it is running on.
    --
    -- `tracking` says which views the game can actually answer:
    --   "both"      - progress differs per character and across the account
    --   "account"   - the game only tracks it account-wide (collections)
    --   "character" - the game only tracks it per character
    -- When a view isn't available for a category, the other one is shown
    -- and the row is tagged so the player knows which they're looking at.
    Categories = {
        { key = "quests",       label = "Quests",       icon = "Interface\\Icons\\INV_Misc_Note_01", tracking = "both" },
        { key = "exploration",  label = "Exploration",  icon = "Interface\\Icons\\INV_Misc_Map_01", tracking = "character" },
        { key = "transmog",     label = "Transmogs",    icon = "Interface\\Icons\\INV_Chest_Cloth_17", tracking = "account" },
        { key = "pets",         label = "Pets",         icon = "Interface\\Icons\\INV_Box_PetCarrier_01", tracking = "account" },
        { key = "decor",        label = "Housing Decor", icon = "Interface\\Icons\\INV_Misc_Lantern_01", tracking = "account", clients = { retail = true } },
        { key = "achievements", label = "Achievements", icon = "Interface\\Icons\\Achievement_Quests_Completed_08", tracking = "both" },
        { key = "rares",        label = "Rare NPCs",    icon = "Interface\\Icons\\Ability_Hunter_MarkedForDeath", tracking = "both" },
        { key = "flightPaths",  label = "Flight Paths", icon = "Interface\\Icons\\Ability_Mount_Gryphon_01", tracking = "character" },
        { key = "recipes",      label = "Recipes",      icon = "Interface\\Icons\\INV_Scroll_03", tracking = "character" },
        { key = "treasures",    label = "Treasures",    icon = "Interface\\Icons\\INV_Misc_Bag_10", tracking = "both" },
    },

    -- Rows shown in the regional summary column (values are percentages).
    RegionStats = {
        { key = "zones",        label = "Zones",        icon = "Interface\\Icons\\INV_Misc_Map_01" },
        { key = "quests",       label = "Quests",       icon = "Interface\\Icons\\INV_Misc_Note_01" },
        { key = "transmog",     label = "Transmog",     icon = "Interface\\Icons\\INV_Chest_Cloth_17" },
        { key = "pets",         label = "Pets",         icon = "Interface\\Icons\\INV_Box_PetCarrier_01" },
        { key = "decor",        label = "Decor",        icon = "Interface\\Icons\\INV_Misc_Lantern_01", clients = { retail = true } },
        { key = "achievements", label = "Achievements", icon = "Interface\\Icons\\Achievement_Quests_Completed_08" },
    },

    -- Progress views. "account" = anything any character has done;
    -- "character" = only what the logged-in character has done.
    Scopes = {
        { key = "account",   label = "Account",   tooltip = "Progress across every character on your account." },
        { key = "character", label = "Character", tooltip = "Progress for this character only - for a 100% run on one character." },
    },
    DefaultScope = "account",

    -- "Only count what this character can do" checkbox default.
    DefaultEligibleOnly = true,

    -- Why something isn't counted, in display order. `always` reasons are
    -- never counted (the content can't be completed by anyone); the others
    -- are counted only when the checkbox is off.
    ExclusionReasons = {
        { key = "class",      short = "other class",   label = "Other classes",           note = "Quests for a different class." },
        { key = "race",       short = "other race",    label = "Other races",             note = "Quests for a different race." },
        { key = "faction",    short = "other faction", label = "Other faction",           note = "Content for the opposite faction." },
        { key = "holiday",    short = "holiday",       label = "Holiday events",          note = "Only available while a holiday is active." },
        { key = "profession", short = "other profession", label = "Other professions",     note = "Recipes for a profession this character doesn't have." },
        { key = "breadcrumb", short = "breadcrumb",    label = "Breadcrumb quests",       note = "Optional lead-ins that lock once you skip them." },
        { key = "repeatable", short = "repeatable",    label = "Repeatable / daily",      note = "Never part of zone completion.", always = true },
        { key = "removed",    short = "removed",       label = "Removed from the game",   note = "No longer obtainable by anyone.", always = true },
        { key = "untrackable", short = "untrackable",  label = "Not trackable",           note = "The game doesn't record this (e.g. old rares without a kill flag).", always = true },
    },

    -- Name of the account-wide macro the "Drag to Hotbar" button creates.
    -- UI/ActionButtonArt.lua recognises the macro on action bars by this name.
    MacroName = "Cozy Zones",

    -- Top-level tabs.
    -- `sections` = the categories listed item by item on that tab.
    Tabs = {
        { key = "zones",        label = "Zones" },
        { key = "quests",       label = "Quests",       sections = { "quests", "rares", "treasures" } },
        { key = "collections",  label = "Collections",  sections = { "pets", "recipes" } },
        { key = "achievements", label = "Achievements", sections = { "achievements", "exploration", "flightPaths" } },
        { key = "transmog",     label = "Transmog",     sections = { "transmog" } },
        { key = "decor",        label = "Decor",        sections = { "decor" }, clients = { retail = true } },
    },

    -- Filter for the item lists on the Quests / Collections / Achievements tabs.
    ListFilters = {
        { key = "missing", label = "Missing", tooltipTitle = "Missing", tooltip = "Only what's still left to do." },
        { key = "done",    label = "Done",    tooltipTitle = "Done",    tooltip = "Only what's already done." },
        { key = "all",     label = "All",     tooltipTitle = "All",     tooltip = "Everything, including what isn't counted (greyed out, with the reason)." },
    },
    DefaultListFilter = "missing",

    -- How a collectible is obtained (shown next to pets, decor and recipes).
    SourceLabels = {
        wild        = "Wild - pet battle",
        vendor      = "Vendor",
        quest       = "Quest reward",
        drop        = "Drop",
        rare        = "Rare drop",
        treasure    = "Treasure",
        achievement = "Achievement",
        petbattle   = "Pet battle quest",
    },

    -- Reasons whose items are hidden from the item lists by default (the
    -- Filter button on each list changes this). Lists only; totals are
    -- decided by the "Only count what this character can do" checkbox.
    DefaultHiddenReasons = { removed = true, class = true, faction = true },
}
