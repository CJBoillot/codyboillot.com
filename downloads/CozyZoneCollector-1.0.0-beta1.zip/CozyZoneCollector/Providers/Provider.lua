-- Provider interface.
--
-- The UI only ever talks to ZC:GetProvider(). Concrete providers (Mock,
-- Retail, Forever) override the three "progress" methods; structure
-- lookups and GetZoneData are shared here because they only depend on the
-- static registry plus those three methods.
--
-- Contract:
--   GetCategories()                          -> Config.Categories filtered to this client
--   GetRegionStats()                         -> Config.RegionStats filtered to this client
--   GetContinents()                          -> array of { id, name }
--   GetContinent(continentID)                -> { id, name, zones } or nil
--   GetZones(continentID)                    -> array of { id, name, icon }
--   GetZoneCompletion(zoneID, scope, data)          -> percent 0-100, or nil if unknown
--                                                      (`data` = the zone data built so far)
--   GetCategoryProgress(zoneID, categoryKey, scope) -> completed, total, excluded
--        (nil, nil if unknown; `excluded` = { [reasonKey] = count } of entries
--         left out of the total, see Config.ExclusionReasons)
--   GetRegionSummary(continentID, scope)            -> { completion, stats = { [key] = percent } } or nil
--   GetZoneData(zoneID, scope)                      -> { id, name, continentID, completion, scope,
--                                                        categories = { [key] = { completed, total, scope, excluded } },
--                                                        excluded = { [reasonKey] = count } (all categories),
--                                                        hasDetail, trackedCount, statusText, isMock } or nil
--   GetStatusText()                                 -> message when data can't be shown yet, or nil
--   GetCategoryItems(zoneID, categoryKey, scope)    -> per-item list for the tabs:
--        { { id, done, counted, reason, entry } } or nil if not available
--   GetItemDisplay(categoryKey, item)               -> { name, icon, color } (name nil while loading)
--   ShowItemTooltip(categoryKey, item, owner)       -> fills GameTooltip for a list row
--   Activate()                                      -> called once when the provider is selected
--
-- `scope` is "account" or "character". For a category whose `tracking`
-- can't answer the requested scope, GetZoneData asks for the scope it does
-- support and records that in the category's `scope` field.

local _, ZC = ...

local BaseProvider = {}
BaseProvider.__index = BaseProvider

-- client: "retail" or "forever"; decides which categories this provider offers.
function ZC:CreateProvider(name, client, isMock)
    return setmetatable({ name = name, client = client, isMock = isMock and true or false }, BaseProvider)
end

function ZC:SetProvider(provider)
    self.provider = provider
end

function ZC:GetProvider()
    return self.provider
end

-- Structure ------------------------------------------------------------------

local function FilterForClient(definitions, client)
    local result = {}
    for _, definition in ipairs(definitions) do
        if not definition.clients or definition.clients[client] then
            result[#result + 1] = definition
        end
    end
    return result
end

function BaseProvider:GetCategories()
    return FilterForClient(ZC.Config.Categories, self.client)
end

function BaseProvider:GetRegionStats()
    return FilterForClient(ZC.Config.RegionStats, self.client)
end

function BaseProvider:GetContinents()
    local result = {}
    for _, continent in ipairs(ZC.Data.Continents) do
        result[#result + 1] = { id = continent.id, name = continent.name }
    end
    return result
end

function BaseProvider:GetContinent(continentID)
    for _, continent in ipairs(ZC.Data.Continents) do
        if continent.id == continentID then
            return continent
        end
    end
end

-- Zone names come from the client (localized) where possible.
function BaseProvider:LookupMapName(zoneID)
    return nil
end

-- Names for every listed zone, built once. Continents are listed oldest
-- first, so when two zones share a name (the original Eversong Woods and
-- Midnight's rebuilt one, or Northrend's and the Broken Isles' Dalaran),
-- the older one is labelled with its continent's tag or name, e.g.
-- "Eversong Woods (Classic)", "Dalaran (Northrend)".
function BaseProvider:BuildZoneNames()
    local names, firstByName = {}, {}
    for _, continent in ipairs(ZC.Data.Continents) do
        for _, zoneID in ipairs(continent.zones) do
            local zone = ZC.Data.Zones[zoneID]
            local name = (zone and zone.name) or self:LookupMapName(zoneID) or ("Zone " .. zoneID)
            local older = firstByName[name]
            if older and older.zoneID ~= zoneID then
                names[older.zoneID] = string.format("%s (%s)", name, older.continent.tag or older.continent.name)
            end
            firstByName[name] = { zoneID = zoneID, continent = continent }
            names[zoneID] = names[zoneID] or name
        end
    end
    return names
end

function BaseProvider:GetZoneName(zoneID)
    self.zoneNames = self.zoneNames or self:BuildZoneNames()
    return self.zoneNames[zoneID] or self:LookupMapName(zoneID) or ("Zone " .. zoneID)
end

function BaseProvider:GetZoneIcon(zone)
    return zone.icon
end

-- 1 = Horde, 2 = Alliance, nil if unknown.
function BaseProvider:GetPlayerFactionID()
    return nil
end

-- The listed zone the player is standing in (sub-zones resolve to their
-- parent zone), plus the raw map name for messages. nil if not listed.
function BaseProvider:GetCurrentZone()
    return nil, nil
end

-- Zones of a continent, sorted by name: { id, name, faction, continentID }.
function BaseProvider:GetZones(continentID)
    local result = {}
    local continent = self:GetContinent(continentID)
    if not continent then
        return result
    end
    for _, zoneID in ipairs(continent.zones) do
        local zone = ZC.Data.Zones[zoneID]
        if zone then
            result[#result + 1] = {
                id = zone.id,
                name = self:GetZoneName(zone.id),
                faction = zone.faction,
                continentID = zone.continentID,
            }
        end
    end
    table.sort(result, function(a, b) return a.name < b.name end)
    return result
end

-- Zone numbers are recomputed once per window refresh; MainFrame clears
-- this cache at the start of each refresh so the sidebar, overview and
-- region summary share one computation.
function BaseProvider:ClearCache()
    self.zoneDataCache = {}
end

-- Returns the scope a category can actually be shown in for a requested view.
function BaseProvider:ResolveScope(category, requestedScope)
    if category.tracking == "account" or category.tracking == "character" then
        return category.tracking
    end
    return requestedScope
end

-- Lifecycle / status (overridden as needed) -----------------------------------

function BaseProvider:Activate()
end

function BaseProvider:GetStatusText()
    return nil
end

-- Item-level detail (Quests / Collections / Achievements tabs) --------------

function BaseProvider:GetCategoryItems(zoneID, categoryKey, scope)
    return nil
end

function BaseProvider:GetItemDisplay(categoryKey, item)
    return { name = tostring(item.id) }
end

function BaseProvider:ShowItemTooltip(categoryKey, item, owner)
end

function BaseProvider:GetCategory(categoryKey)
    for _, category in ipairs(self:GetCategories()) do
        if category.key == categoryKey then
            return category
        end
    end
end

-- Progress (overridden by concrete providers) ---------------------------------

function BaseProvider:GetZoneCompletion(zoneID, scope)
    return nil
end

function BaseProvider:GetCategoryProgress(zoneID, categoryKey, scope)
    return nil, nil
end

function BaseProvider:GetRegionSummary(continentID, scope)
    return nil
end

-- Composite -------------------------------------------------------------------

function BaseProvider:GetZoneData(zoneID, scope)
    local zone = ZC.Data.Zones[zoneID]
    if not zone then
        return nil
    end

    self.zoneDataCache = self.zoneDataCache or {}
    local cacheKey = zoneID .. ":" .. tostring(scope)
    if self.zoneDataCache[cacheKey] then
        return self.zoneDataCache[cacheKey]
    end

    local data = {
        id = zone.id,
        name = self:GetZoneName(zone.id),
        icon = self:GetZoneIcon(zone),
        faction = zone.faction,
        continentID = zone.continentID,
        scope = scope,
        categories = {},
        excluded = {},
        hasDetail = false,
        trackedCount = 0,
        isMock = self.isMock,
    }

    for _, category in ipairs(self:GetCategories()) do
        local categoryScope = self:ResolveScope(category, scope)
        local completed, total, excluded = self:GetCategoryProgress(zoneID, category.key, categoryScope)
        if completed and total then
            data.categories[category.key] = {
                completed = completed, total = total, scope = categoryScope, excluded = excluded,
            }
            for reason, count in pairs(excluded or {}) do
                data.excluded[reason] = (data.excluded[reason] or 0) + count
            end
            data.hasDetail = true
            data.trackedCount = data.trackedCount + 1
        end
    end

    -- Providers may derive the overall number from the categories.
    data.completion = self:GetZoneCompletion(zoneID, scope, data)

    -- Read after the categories: looking them up can complete a pending load.
    data.statusText = self:GetStatusText()

    self.zoneDataCache[cacheKey] = data
    return data
end
