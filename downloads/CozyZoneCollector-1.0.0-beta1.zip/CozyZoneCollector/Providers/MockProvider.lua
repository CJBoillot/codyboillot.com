-- MockProvider: serves development data so the UI can be built and tested
-- without touching any game API. All numbers are fake. It stands in for
-- the Retail client, so Retail-only categories (e.g. housing decor) show.

local _, ZC = ...

local MockProvider = ZC:CreateProvider("Mock", "retail", true)
ZC.Providers.Mock = MockProvider

-- Summary-only completion for zones that have no detail file yet.
local MOCK_ZONE_COMPLETION = {
    [52] = { account = 33, character = 12 }, -- Westfall
    [49] = { account = 14, character = 0 },  -- Redridge Mountains
    [47] = { account = 0,  character = 0 },  -- Duskwood
}

local MOCK_REGION_SUMMARY = {
    [13] = {
        account = {
            completion = 43,
            stats = { zones = 42, quests = 51, transmog = 36, pets = 61, decor = 22, achievements = 47 },
        },
        character = {
            completion = 24,
            -- Account-wide collections are the same in both views.
            stats = { zones = 18, quests = 30, transmog = 36, pets = 61, decor = 22, achievements = 29 },
        },
    },
}

local MOCK_ZONE_NAMES = { [37] = "Elwynn Forest", [52] = "Westfall", [49] = "Redridge Mountains", [47] = "Duskwood" }

function MockProvider:LookupMapName(zoneID)
    return MOCK_ZONE_NAMES[zoneID]
end

function MockProvider:GetZoneIcon()
    return "Interface\\Icons\\INV_Misc_Map_01"
end

function MockProvider:GetZoneCompletion(zoneID, scope)
    local detail = ZC.Data.ZoneDetails[zoneID]
    local byScope = detail and detail.completion or MOCK_ZONE_COMPLETION[zoneID]
    return byScope and byScope[scope]
end

-- Sample "not counted" breakdown so the UI can be exercised.
local MOCK_EXCLUDED_QUESTS = { class = 24, holiday = 12, breadcrumb = 9, repeatable = 4, removed = 40 }

function MockProvider:GetCategoryProgress(zoneID, categoryKey, scope)
    local detail = ZC.Data.ZoneDetails[zoneID]
    local category = detail and detail.categories[categoryKey]
    local progress = category and category[scope]
    if progress then
        local excluded = categoryKey == "quests" and MOCK_EXCLUDED_QUESTS or nil
        return progress.completed, progress.total, excluded
    end
    return nil, nil
end

function MockProvider:GetRegionSummary(continentID, scope)
    local summary = MOCK_REGION_SUMMARY[continentID]
    return summary and summary[scope]
end
