-- RetailProvider: real progress for World of Warcraft Retail.
--
-- Content lists (what exists in a zone) come from ZC.Sources.Content, the
-- data bundled with the addon. Completion is checked with Blizzard APIs,
-- so Account vs Character is decided here:
--   quests       - C_QuestLog.IsQuestFlaggedCompleted (character)
--                  C_QuestLog.IsQuestFlaggedCompletedOnAccount (account)
--   rares/treasures - the same quest checks on their hidden kill/loot flag
--   achievements - GetAchievementInfo: `completed` (account),
--                  `wasEarnedByMe` (character)
--   exploration  - per character: the zone's map areas (from ATT) checked
--                  with C_MapExplorationInfo.GetExploredAreaIDsAtPosition.
--                  (The "Explore <Zone>" achievement is account-wide, so it
--                  can't say what this character has explored.)
--   transmog     - C_TransmogCollection: this source, or any other source
--                  of the same appearance, is known (account-wide)
--   pets         - C_PetJournal.GetNumCollectedInfo (account-wide)
--   decor        - C_HousingCatalog entry counts (account-wide)
--   flightPaths  - known taxi nodes, recorded per character whenever a
--                  flight map opens (the game only reveals them then)
--   recipes      - known recipe spells, plus recipes recorded per character
--                  whenever a profession window opens

local _, ZC = ...

local Content = ZC.Sources.Content

local RetailProvider = ZC:CreateProvider("Retail", "retail", false)
ZC.Providers.Retail = RetailProvider

-- Enum.FlightPathState: 0 = current, 1 = reachable, 2 = unreachable.
local FLIGHT_PATH_UNREACHABLE = 2

-- Positions in GetAchievementInfo's returns.
local ACHIEVEMENT_COMPLETED = 4
local ACHIEVEMENT_EARNED_BY_ME = 13

-- Decor counts above this are Blizzard's "unknown" sentinel, not real.
local DECOR_COUNT_SANITY_LIMIT = 1000000

--------------------------------------------------------------------------------
-- Single-thing checks
--------------------------------------------------------------------------------

local function IsQuestDone(questID, scope)
    if not questID then
        return false -- e.g. a rare the game never flags as killed
    end
    if C_QuestLog.IsQuestFlaggedCompleted(questID) then
        return true
    end
    if scope == "account" and C_QuestLog.IsQuestFlaggedCompletedOnAccount then
        return C_QuestLog.IsQuestFlaggedCompletedOnAccount(questID) and true or false
    end
    return false
end

local function IsAchievementDone(achievementID, scope)
    local index = scope == "account" and ACHIEVEMENT_COMPLETED or ACHIEVEMENT_EARNED_BY_ME
    return select(index, GetAchievementInfo(achievementID)) and true or false
end

-- Appearance checks are the most expensive; remember answers until the
-- collection changes (TRANSMOG_COLLECTION_UPDATED clears this).
local appearanceCache = {}

local function CheckAppearanceCollected(sourceID)
    local transmog = C_TransmogCollection
    if transmog.PlayerHasTransmogItemModifiedAppearance(sourceID) then
        return true
    end
    local info = transmog.GetSourceInfo(sourceID)
    if not info then
        return false
    end
    if info.isCollected then
        return true
    end
    -- Same look unlocked from a different item still counts.
    for _, otherSourceID in ipairs(info.visualID and transmog.GetAllAppearanceSources(info.visualID) or {}) do
        if transmog.PlayerHasTransmogItemModifiedAppearance(otherSourceID) then
            return true
        end
    end
    return false
end

local function IsAppearanceCollected(sourceID)
    local cached = appearanceCache[sourceID]
    if cached == nil then
        cached = CheckAppearanceCollected(sourceID)
        appearanceCache[sourceID] = cached
    end
    return cached
end

local function IsPetCollected(speciesID)
    local numCollected = C_PetJournal.GetNumCollectedInfo(speciesID)
    return (numCollected or 0) > 0
end

local function IsDecorOwned(decorID)
    local catalog = C_HousingCatalog
    if catalog and catalog.GetCatalogEntryInfoByRecordID and Enum.HousingCatalogEntryType then
        local ok, info = pcall(catalog.GetCatalogEntryInfoByRecordID, Enum.HousingCatalogEntryType.Decor, decorID, true)
        if ok and type(info) == "table" then
            local owned = (info.numPlaced or 0) + (info.quantity or 0) + (info.remainingRedeemable or 0)
            if owned > 0 and owned < DECOR_COUNT_SANITY_LIMIT then
                return true
            end
        end
    end
    return false
end

local function IsFlightPathKnown(flightPathID)
    return ZC:GetCharacterDB().knownFlightPaths[flightPathID] and true or false
end

local function Contains(list, value)
    for _, item in ipairs(list or {}) do
        if item == value then
            return true
        end
    end
    return false
end

-- Map exploration (the fog on the world map) is per character. Ask the game
-- which areas are uncovered at the area's known points.
local function IsAreaExplored(entry)
    local getExplored = C_MapExplorationInfo and C_MapExplorationInfo.GetExploredAreaIDsAtPosition
    if getExplored and entry.coords then
        for mapID, points in pairs(entry.coords) do
            for _, point in ipairs(points) do
                local ok, areaIDs = pcall(getExplored, mapID, CreateVector2D(point[1] / 100, point[2] / 100))
                if ok and Contains(areaIDs, entry.id) then
                    return true
                end
            end
        end
    end
    return false
end

local function IsSpellKnownAnyAPI(spellID)
    if C_SpellBook and C_SpellBook.IsSpellKnown and C_SpellBook.IsSpellKnown(spellID) then
        return true
    end
    return IsPlayerSpell and IsPlayerSpell(spellID) or false
end

local function IsRecipeKnown(recipeID)
    return ZC:GetCharacterDB().knownRecipes[recipeID] or IsSpellKnownAnyAPI(recipeID)
end

--------------------------------------------------------------------------------
-- Counting
--------------------------------------------------------------------------------

-- Reasons that never count, whatever the checkbox says.
local ALWAYS_EXCLUDED = {}
for _, reason in ipairs(ZC.Config.ExclusionReasons) do
    if reason.always then
        ALWAYS_EXCLUDED[reason.key] = true
    end
end

local function IsCounted(entry)
    if not entry.reason then
        return true
    end
    return not ALWAYS_EXCLUDED[entry.reason] and not ZC:IsEligibleOnly()
end

-- Counts a content list ({ id, reason } entries) with `isDone(entry)`, and
-- tallies what was left out and why.
local function CountEntries(entries, isDone)
    local completed, total, excluded = 0, 0, {}
    for _, entry in ipairs(entries) do
        if IsCounted(entry) then
            total = total + 1
            if isDone(entry) then
                completed = completed + 1
            end
        else
            excluded[entry.reason] = (excluded[entry.reason] or 0) + 1
        end
    end
    return completed, total, excluded
end

-- One entry per category: which content list it reads and how to check an
-- entry for the requested scope.
local CATEGORY_COUNTERS = {
    quests       = { list = "quests",       isDone = function(e, scope) return IsQuestDone(e.id, scope) end },
    rares        = { list = "rares",        isDone = function(e, scope) return IsQuestDone(e.questID, scope) end },
    treasures    = { list = "treasures",    isDone = function(e, scope) return IsQuestDone(e.questID, scope) end },
    achievements = { list = "achievements", isDone = function(e, scope) return IsAchievementDone(e.id, scope) end },
    transmog     = { list = "transmog",     isDone = function(e) return IsAppearanceCollected(e.id) end },
    pets         = { list = "pets",         isDone = function(e) return IsPetCollected(e.id) end },
    decor        = { list = "decor",        isDone = function(e) return IsDecorOwned(e.id) end },
    flightPaths  = { list = "flightPaths",  isDone = function(e) return IsFlightPathKnown(e.id) end },
    exploration  = { list = "exploration",  isDone = function(e) return IsAreaExplored(e) end },
    recipes      = { list = "recipes",      isDone = function(e) return IsRecipeKnown(e.id) end },
}

--------------------------------------------------------------------------------
-- Provider interface
--------------------------------------------------------------------------------

function RetailProvider:GetStatusText()
    if not Content:HasData() then
        return "Zone data file is missing - reinstall Cozy Zone Collector."
    end
end

function RetailProvider:GetCategoryProgress(zoneID, categoryKey, scope)
    local content = Content:GetZoneContent(zoneID)

    local counter = CATEGORY_COUNTERS[categoryKey]
    if not content or not counter then
        return nil, nil
    end

    local completed, total, excluded = CountEntries(content[counter.list], function(entry)
        return counter.isDone(entry, scope)
    end)
    if total == 0 and not next(excluded) then
        return nil, nil -- the zone has none of this
    end
    return completed, total, excluded
end

-- Per-item list for the Quests / Collections / Achievements tabs.
function RetailProvider:GetCategoryItems(zoneID, categoryKey, scope)
    local content = Content:GetZoneContent(zoneID)
    local counter = CATEGORY_COUNTERS[categoryKey]
    local category = self:GetCategory(categoryKey)
    if not content or not counter or not category then
        return nil
    end
    local itemScope = self:ResolveScope(category, scope)
    local items = {}
    for _, entry in ipairs(content[counter.list]) do
        -- pcall: one odd entry must never break the whole list.
        local ok, done = pcall(counter.isDone, entry, itemScope)
        items[#items + 1] = {
            id = entry.id,
            entry = entry,
            counted = IsCounted(entry),
            reason = entry.reason,
            done = ok and done and true or false,
        }
    end
    return items
end

--------------------------------------------------------------------------------
-- Names, icons and tooltips for list rows
--------------------------------------------------------------------------------

local ICONS = {
    quests      = "Interface\\GossipFrame\\AvailableQuestIcon",
    rares       = "Interface\\Icons\\Ability_Hunter_MarkedForDeath",
    treasures   = "Interface\\Icons\\INV_Misc_Bag_10",
    exploration = "Interface\\Icons\\INV_Misc_Map_01",
    flightPaths = "Interface\\Icons\\Ability_Mount_Gryphon_01",
    unknown     = "Interface\\Icons\\INV_Misc_QuestionMark",
}

-- Item names arrive asynchronously; ask once and redraw when they land.
local requestedItems = {}
local function RequestItem(itemID)
    if itemID and not requestedItems[itemID] and C_Item and C_Item.RequestLoadItemDataByID then
        requestedItems[itemID] = true
        C_Item.RequestLoadItemDataByID(itemID)
    end
end

local function ItemDisplay(itemID)
    if not itemID then
        return nil
    end
    local name = C_Item.GetItemNameByID(itemID)
    if not name then
        RequestItem(itemID)
    end
    local quality = C_Item.GetItemQualityByID and C_Item.GetItemQualityByID(itemID)
    local color = quality and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality]
    return { name = name, icon = C_Item.GetItemIconByID(itemID), color = color and color.color }
end

local function SpellNameAndIcon(spellID)
    if C_Spell and C_Spell.GetSpellName then
        return C_Spell.GetSpellName(spellID), C_Spell.GetSpellTexture(spellID)
    end
end

local requestedQuests = {}
local DISPLAY = {
    quests = function(item)
        local title = C_QuestLog.GetTitleForQuestID(item.id)
        if not title and not requestedQuests[item.id] and C_QuestLog.RequestLoadQuestByID then
            requestedQuests[item.id] = true
            C_QuestLog.RequestLoadQuestByID(item.id)
        end
        return { name = title, icon = ICONS.quests }
    end,
    achievements = function(item)
        local _, name, _, _, _, _, _, _, _, icon = GetAchievementInfo(item.id)
        return { name = name, icon = icon }
    end,
    exploration = function(item)
        local name = C_Map.GetAreaInfo(item.id)
        return { name = name or ("Area " .. item.id), icon = ICONS.exploration }
    end,
    transmog = function(item)
        local info = C_TransmogCollection.GetSourceInfo(item.id)
        local display = ItemDisplay(info and info.itemID) or {}
        display.name = (info and info.name ~= "" and info.name) or display.name
        return display
    end,
    pets = function(item)
        local name, icon = C_PetJournal.GetPetInfoBySpeciesID(item.id)
        return { name = name, icon = icon }
    end,
    decor = function(item)
        local display = ItemDisplay(item.entry.itemID)
        if display and display.name then
            return display
        end
        local catalog = C_HousingCatalog
        if catalog and catalog.GetCatalogEntryInfoByRecordID and Enum.HousingCatalogEntryType then
            local ok, info = pcall(catalog.GetCatalogEntryInfoByRecordID, Enum.HousingCatalogEntryType.Decor, item.id, true)
            if ok and type(info) == "table" and info.name then
                return { name = info.name, icon = info.iconTexture or (display and display.icon) }
            end
        end
        return display or { name = nil }
    end,
    recipes = function(item)
        local name, icon = SpellNameAndIcon(item.id)
        return { name = name, icon = icon }
    end,
    rares = function(item)
        return { name = "Rare creature #" .. item.id, icon = ICONS.rares }
    end,
    treasures = function(item)
        return { name = item.entry.name or ("Treasure #" .. item.id), icon = ICONS.treasures }
    end,
    flightPaths = function(item)
        return { name = item.entry.name or ("Flight point #" .. item.id), icon = ICONS.flightPaths }
    end,
}

function RetailProvider:GetItemDisplay(categoryKey, item)
    local builder = DISPLAY[categoryKey]
    local ok, display = pcall(builder or function() return {} end, item)
    display = ok and display or {}
    display.icon = display.icon or ICONS.unknown
    display.source = item.entry and item.entry.source and ZC.Config.SourceLabels[item.entry.source]
    return display
end

-- Uses the game's own tooltips where one exists (quests, achievements,
-- items, spells), then adds this addon's status line.
local TOOLTIP_FILLERS = {
    quests = function(item) GameTooltip:SetHyperlink("quest:" .. item.id) end,
    achievements = function(item) GameTooltip:SetHyperlink(GetAchievementLink(item.id)) end,
    transmog = function(item)
        local info = C_TransmogCollection.GetSourceInfo(item.id)
        if info and info.itemID then GameTooltip:SetItemByID(info.itemID) end
    end,
    decor = function(item)
        if item.entry.itemID then GameTooltip:SetItemByID(item.entry.itemID) end
    end,
    recipes = function(item) GameTooltip:SetSpellByID(item.id) end,
}

function RetailProvider:ShowItemTooltip(categoryKey, item, owner)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    local filler = TOOLTIP_FILLERS[categoryKey]
    local ok = filler and pcall(filler, item)
    local display = self:GetItemDisplay(categoryKey, item)
    if not ok or GameTooltip:NumLines() == 0 then
        GameTooltip:SetText(display.name or "Loading...", 1, 1, 1)
    end
    if display.source then
        GameTooltip:AddLine("Source: " .. display.source, NORMAL_FONT_COLOR:GetRGB())
    end
    GameTooltip:Show()
end

-- Item-weighted across the categories already counted for this zone.
function RetailProvider:GetZoneCompletion(zoneID, scope, data)
    local completed, total = 0, 0
    for _, progress in pairs(data and data.categories or {}) do
        completed, total = completed + progress.completed, total + progress.total
    end
    if total == 0 then
        return nil
    end
    return completed / total * 100
end

function RetailProvider:LookupMapName(zoneID)
    local info = C_Map.GetMapInfo(zoneID)
    return info and info.name
end

-- The zone's "Explore <Zone>" achievement icon is the zone's artwork.
function RetailProvider:GetZoneIcon(zone)
    if zone.exploreAchievementID then
        local icon = select(10, GetAchievementInfo(zone.exploreAchievementID))
        if icon then
            return icon
        end
    end
    return "Interface\\Icons\\INV_Misc_Map_01"
end

-- Walk up from the player's map (e.g. Northshire) until a listed zone is
-- found (Elwynn Forest).
local MAX_MAP_DEPTH = 10
function RetailProvider:GetCurrentZone()
    local mapID = C_Map.GetBestMapForUnit("player")
    local here = mapID and C_Map.GetMapInfo(mapID)
    local hereName = here and here.name
    for _ = 1, MAX_MAP_DEPTH do
        if not mapID or mapID == 0 then
            break
        end
        if ZC.Data.Zones[mapID] then
            return mapID, hereName
        end
        local info = C_Map.GetMapInfo(mapID)
        mapID = info and info.parentMapID
    end
    return nil, hereName
end

local PLAYER_FACTION_IDS = { Horde = 1, Alliance = 2 }
function RetailProvider:GetPlayerFactionID()
    return PLAYER_FACTION_IDS[UnitFactionGroup("player")]
end

-- Regional numbers are built from the zone numbers: "zones" is the share of
-- zones at 100%, the rest pool every zone's items for that category.
function RetailProvider:GetRegionSummary(continentID, scope)
    local zones = self:GetZones(continentID)
    local pooled = {}
    local completionSum, zonesWithData, zonesComplete = 0, 0, 0

    for _, zone in ipairs(zones) do
        local data = self:GetZoneData(zone.id, scope)
        if data and data.completion then
            completionSum = completionSum + data.completion
            zonesWithData = zonesWithData + 1
            if data.completion >= 100 then
                zonesComplete = zonesComplete + 1
            end
        end
        for key, progress in pairs(data and data.categories or {}) do
            local pool = pooled[key] or { completed = 0, total = 0 }
            pool.completed = pool.completed + progress.completed
            pool.total = pool.total + progress.total
            pooled[key] = pool
        end
    end

    if zonesWithData == 0 then
        return nil
    end

    local stats = { zones = zonesComplete / #zones * 100 }
    for key, pool in pairs(pooled) do
        if pool.total > 0 then
            stats[key] = pool.completed / pool.total * 100
        end
    end
    return { completion = completionSum / zonesWithData, stats = stats }
end

--------------------------------------------------------------------------------
-- Events
--------------------------------------------------------------------------------

local function RecordKnownFlightPaths()
    local mapID = GetTaxiMapID and GetTaxiMapID()
    local nodes = mapID and mapID >= 0 and C_TaxiMap.GetAllTaxiNodes(mapID)
    if not nodes then
        return
    end
    local known = ZC:GetCharacterDB().knownFlightPaths
    for _, node in ipairs(nodes) do
        if node.state and node.state < FLIGHT_PATH_UNREACHABLE then
            known[node.nodeID] = true
        end
    end
end

-- The game only lists a profession's recipes while its window is open, so
-- remember what this character knows each time one opens.
local function RecordKnownRecipes()
    local tradeSkill = C_TradeSkillUI
    if not (tradeSkill and tradeSkill.GetAllRecipeIDs and tradeSkill.GetRecipeInfo) then
        return
    end
    local known = ZC:GetCharacterDB().knownRecipes
    for _, recipeID in ipairs(tradeSkill.GetAllRecipeIDs() or {}) do
        local info = tradeSkill.GetRecipeInfo(recipeID)
        if info and info.learned then
            known[recipeID] = true
        end
    end
end

-- Events after which the window's numbers may have changed.
local REFRESH_EVENTS = {
    "TAXIMAP_OPENED",
    "QUEST_TURNED_IN",
    "ACHIEVEMENT_EARNED",
    "TRANSMOG_COLLECTION_UPDATED",
    "NEW_PET_ADDED",
    "SKILL_LINES_CHANGED",
    "TRADE_SKILL_LIST_UPDATE",
    "NEW_RECIPE_LEARNED",
}

-- Name/icon data arriving for list rows; these only need a redraw.
local DISPLAY_EVENTS = {
    QUEST_DATA_LOAD_RESULT = true,
    ITEM_DATA_LOAD_RESULT = true,
    GET_ITEM_INFO_RECEIVED = true,
}

local eventFrame

function RetailProvider:Activate()
    if eventFrame then
        return
    end
    eventFrame = CreateFrame("Frame")
    for _, event in ipairs(REFRESH_EVENTS) do
        -- pcall: an event renamed in a future patch shouldn't break loading.
        pcall(eventFrame.RegisterEvent, eventFrame, event)
    end
    for event in pairs(DISPLAY_EVENTS) do
        pcall(eventFrame.RegisterEvent, eventFrame, event)
    end
    eventFrame:SetScript("OnEvent", function(_, event)
        if DISPLAY_EVENTS[event] then
            ZC:NotifyDisplayChanged()
            return
        end
        if event == "TAXIMAP_OPENED" then
            RecordKnownFlightPaths()
        elseif event == "TRADE_SKILL_LIST_UPDATE" then
            RecordKnownRecipes()
        elseif event == "TRANSMOG_COLLECTION_UPDATED" then
            wipe(appearanceCache)
        elseif event == "SKILL_LINES_CHANGED" then
            Content:InvalidateCache() -- professions decide which recipes count
        end
        ZC:NotifyDataChanged()
    end)
end
