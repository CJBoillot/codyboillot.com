-- ForeverProvider: STUB for World of Warcraft Forever.
--
-- Intentionally empty. Forever's available APIs are unknown until we have
-- beta access, so nothing here guesses at them. When access arrives:
--   1. Confirm how to detect the Forever client (do not assume WOW_PROJECT_* values).
--   2. Confirm whether Forever uses the same uiMapIDs as Retail.
--   2b. Confirm whether Forever has player housing; if so, add "forever"
--       to the decor category's `clients` in Config.lua.
--   3. Implement the three progress methods below.

local _, ZC = ...

local ForeverProvider = ZC:CreateProvider("Forever", "forever", false)
ZC.Providers.Forever = ForeverProvider

function ForeverProvider:GetZoneCompletion(zoneID, scope)
    -- TODO: Forever implementation.
    return nil
end

function ForeverProvider:GetCategoryProgress(zoneID, categoryKey, scope)
    -- TODO: Forever implementation.
    return nil, nil
end

function ForeverProvider:GetRegionSummary(continentID, scope)
    -- TODO: Forever implementation.
    return nil
end
