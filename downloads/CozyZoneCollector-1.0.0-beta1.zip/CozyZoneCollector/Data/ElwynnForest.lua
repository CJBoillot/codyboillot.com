-- Elwynn Forest detail data.
--
-- DEVELOPMENT MOCK DATA. These numbers are placeholders for building the
-- UI and are NOT real Elwynn Forest totals. In a later milestone this file
-- becomes the zone's content definition (quest IDs, rare NPC IDs, treasure
-- IDs, ...) and the provider computes completed/total from live game state.
--
-- Values are split by view. A category only has the views the game can
-- track for it (see `tracking` in Config.lua): collections such as
-- transmog, pets and decor are account-wide only; flight paths and
-- recipes are per character only.

local _, ZC = ...

ZC.Data.ZoneDetails = ZC.Data.ZoneDetails or {}

ZC.Data.ElwynnForest = {
    id = 37, -- Retail uiMapID (see Data/Zones.lua)
    name = "Elwynn Forest",
    isMock = true,

    -- Hard-coded because it is mock data. A real provider will derive this
    -- from the categories (the weighting rule is still to be decided).
    completion = { account = 72, character = 51 },

    categories = {
        quests       = { account = { completed = 84, total = 112 }, character = { completed = 61, total = 112 } },
        exploration  = { account = { completed = 10, total = 12 },  character = { completed = 9,  total = 12 } },
        transmog     = { account = { completed = 23, total = 41 } },
        pets         = { account = { completed = 4,  total = 7 } },
        decor        = { account = { completed = 5,  total = 18 } },
        achievements = { account = { completed = 8,  total = 13 },  character = { completed = 5,  total = 13 } },
        rares        = { account = { completed = 6,  total = 9 },   character = { completed = 2,  total = 9 } },
        flightPaths  = { character = { completed = 2, total = 3 } },
        recipes      = { character = { completed = 3, total = 8 } },
        treasures    = { account = { completed = 7,  total = 10 },  character = { completed = 3,  total = 10 } },
    },
}

ZC.Data.ZoneDetails[ZC.Data.ElwynnForest.id] = ZC.Data.ElwynnForest
