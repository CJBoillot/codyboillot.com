-- CollectionList: a vertical list of progress rows (icon, label, value, bar).
-- Used for the zone's category breakdown (completed / total) and for the
-- regional summary (percentages). Rows are built once from a definition
-- list (the provider's GetCategories / GetRegionStats) and only their values change.

local _, ZC = ...

local Styles = ZC.UI.Styles

local CollectionList = {}
ZC.UI.CollectionList = CollectionList

local DEFAULT_ROW_HEIGHT = 34
local MOCK_NOTE_COLOR = GRAY_FONT_COLOR

-- Shown when a row is in a different view than the one selected, because
-- the game only tracks that category one way.
local SCOPE_TAGS = {
    account = {
        tag = "Account-wide",
        note = "The game tracks this account-wide, so it is the same in both views.",
    },
    character = {
        tag = "This character",
        note = "The game tracks this per character only.",
    },
}

local function Row_OnEnter(row)
    Styles.ShowSimpleTooltip(row, row.definition.label, row.tooltipLines)
end

local function CreateRow(parent, definition, height)
    local row = CreateFrame("Button", nil, parent)
    row:SetHeight(height)
    row.definition = definition
    row.tooltipLines = {}

    row:SetHighlightTexture(Styles.Textures.listHighlight, "ADD")
    row:GetHighlightTexture():SetAlpha(0.35)

    local iconSize = height - 8
    row.Icon = row:CreateTexture(nil, "ARTWORK")
    row.Icon:SetSize(iconSize, iconSize)
    row.Icon:SetPoint("LEFT", 4, 0)
    row.Icon:SetTexture(definition.icon)
    row.Icon:SetTexCoord(0.08, 0.92, 0.08, 0.92) -- trim the default icon border

    row.Label = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    row.Label:SetPoint("TOPLEFT", row.Icon, "TOPRIGHT", 8, -1)
    row.Label:SetText(definition.label)

    row.Tag = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.Tag:SetPoint("LEFT", row.Label, "RIGHT", 6, 0)

    row.Value = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.Value:SetPoint("TOPRIGHT", row, "TOPRIGHT", -6, -5)
    row.Value:SetJustifyH("RIGHT")

    row.Bar = Styles.CreateProgressBar(row, 6, false)
    row.Bar:SetPoint("BOTTOMLEFT", row.Icon, "BOTTOMRIGHT", 8, 1)
    row.Bar:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", -6, 5)

    row:SetScript("OnEnter", Row_OnEnter)
    row:SetScript("OnLeave", Styles.HideTooltip)
    return row
end

-- Writes text, bar and tooltip for one row.
-- `value` is { completed, total, scope } in "count" mode or a number in
-- "percent" mode. `viewScope` is the view the player selected.
local function UpdateRow(row, value, valueFormat, isMock, viewScope)
    local text, fraction, detail

    if valueFormat == "percent" and type(value) == "number" then
        fraction = value / 100
        text = Styles.FormatPercent(value)
        detail = text .. " complete"
    elseif valueFormat == "count" and type(value) == "table" and value.total and value.total > 0 then
        fraction = value.completed / value.total
        text = string.format("%d / %d", value.completed, value.total)
        detail = string.format("%s done (%s)", text, Styles.FormatPercent(fraction * 100))
    end

    if text then
        row.Value:SetText(text)
        row.Value:SetTextColor(Styles.PercentColor(fraction * 100))
    elseif type(value) == "table" and value.total == 0 then
        -- The zone has these, but none can be counted (see the breakdown).
        row.Value:SetText("--")
        row.Value:SetTextColor(DISABLED_FONT_COLOR:GetRGB())
        detail = "Nothing here can be counted"
    else
        row.Value:SetText(valueFormat == "percent" and "--" or "-- / --")
        row.Value:SetTextColor(DISABLED_FONT_COLOR:GetRGB())
        detail = "Not tracked yet"
    end
    Styles.SetBarFraction(row.Bar, fraction)

    local scopeTag = type(value) == "table" and value.scope ~= viewScope and SCOPE_TAGS[value.scope]
    row.Tag:SetText(scopeTag and scopeTag.tag or "")

    wipe(row.tooltipLines)
    row.tooltipLines[1] = { text = detail }
    if scopeTag then
        row.tooltipLines[#row.tooltipLines + 1] = { text = scopeTag.note, color = NORMAL_FONT_COLOR }
    end
    Styles.AddExclusionLines(row.tooltipLines, type(value) == "table" and value.excluded)

    if isMock and text then
        row.tooltipLines[#row.tooltipLines + 1] = { text = "Development mock data", color = MOCK_NOTE_COLOR }
    end
end

local ListMethods = {}

-- valuesByKey: table keyed by definition.key (missing keys show as untracked).
function ListMethods:SetValues(valuesByKey, isMock, viewScope)
    valuesByKey = valuesByKey or {}
    for _, row in ipairs(self.rows) do
        UpdateRow(row, valuesByKey[row.definition.key], self.valueFormat, isMock, viewScope)
    end
end

-- options.valueFormat: "count" or "percent"; options.rowHeight optional.
function CollectionList.Create(parent, definitions, options)
    local list = CreateFrame("Frame", nil, parent)
    local rowHeight = options.rowHeight or DEFAULT_ROW_HEIGHT

    list.valueFormat = options.valueFormat
    list.rows = {}

    for index, definition in ipairs(definitions) do
        local row = CreateRow(list, definition, rowHeight)
        row:SetPoint("TOPLEFT", list, "TOPLEFT", 0, -(index - 1) * rowHeight)
        row:SetPoint("TOPRIGHT", list, "TOPRIGHT", 0, -(index - 1) * rowHeight)
        list.rows[index] = row
    end
    list:SetHeight(#definitions * rowHeight)

    for name, method in pairs(ListMethods) do
        list[name] = method
    end
    return list
end
