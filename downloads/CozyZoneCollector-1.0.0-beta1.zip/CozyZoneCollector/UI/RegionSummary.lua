-- RegionSummary: the right column of the Zones tab. Shows overall progress
-- for the continent containing the selected zone.

local _, ZC = ...

local Styles = ZC.UI.Styles

local RegionSummary = {}
ZC.UI.RegionSummary = RegionSummary

local SummaryMethods = {}

-- summary: provider region summary or nil; continentName: string;
-- scope: the selected view.
function SummaryMethods:SetRegion(summary, continentName, scope)
    self.Title:SetText(continentName or "")

    local completion = summary and summary.completion
    if completion then
        self.Completion:SetText(Styles.FormatPercent(completion) .. " Complete")
        self.Completion:SetTextColor(HIGHLIGHT_FONT_COLOR:GetRGB())
    else
        self.Completion:SetText("Not tracked yet")
        self.Completion:SetTextColor(DISABLED_FONT_COLOR:GetRGB())
    end
    Styles.SetBarFraction(self.CompletionBar, completion and completion / 100)

    self.Stats:SetValues(summary and summary.stats, ZC:GetProvider().isMock, scope)
end

function RegionSummary.Create(parent)
    local panel = CreateFrame("Frame", nil, parent)

    panel.Label = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    panel.Label:SetPoint("TOPLEFT", 12, -12)
    panel.Label:SetText("REGION")

    panel.Title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    panel.Title:SetPoint("TOPLEFT", 12, -28)
    panel.Title:SetPoint("TOPRIGHT", -12, -28)
    panel.Title:SetJustifyH("LEFT")

    panel.Completion = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    panel.Completion:SetPoint("TOPLEFT", panel.Title, "BOTTOMLEFT", 0, -6)

    panel.CompletionBar = Styles.CreateProgressBar(panel, 12, false)
    panel.CompletionBar:SetPoint("TOPLEFT", 14, -78)
    panel.CompletionBar:SetPoint("TOPRIGHT", -14, -78)

    panel.Divider = Styles.CreateDivider(panel)
    panel.Divider:SetPoint("TOPLEFT", 6, -102)
    panel.Divider:SetPoint("TOPRIGHT", -6, -102)

    panel.Stats = ZC.UI.CollectionList.Create(panel, ZC:GetProvider():GetRegionStats(), {
        valueFormat = "percent",
        rowHeight = 32,
    })
    panel.Stats:SetPoint("TOPLEFT", 4, -114)
    panel.Stats:SetPoint("TOPRIGHT", -4, -114)

    for name, method in pairs(SummaryMethods) do
        panel[name] = method
    end
    return panel
end
