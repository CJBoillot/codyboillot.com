-- ItemList: the scrolling item list used by the Quests, Collections and
-- Achievements tabs. Shows one or more sections (e.g. Transmog, Pets, ...)
-- for the selected zone, each with a header and its items, filtered by
-- Missing / Done / All.
--
-- Rows are recycled (only the visible ones exist), so zones with hundreds of
-- items (cities) stay cheap. Names and icons are fetched per visible row
-- through callbacks, so this module never touches game APIs itself.

local _, ZC = ...

local Styles = ZC.UI.Styles

local ItemList = {}
ZC.UI.ItemList = ItemList

local ROW_HEIGHT = 24
local ICON_SIZE = 20
local SCROLL_STEP = 3
local FALLBACK_VISIBLE_ROWS = 16
local DONE_CHECK = "Interface\\RaidFrame\\ReadyCheck-Ready"

local REASON_LABELS = {}
for _, reason in ipairs(ZC.Config.ExclusionReasons) do
    REASON_LABELS[reason.key] = reason.label
end

--------------------------------------------------------------------------------
-- Rows
--------------------------------------------------------------------------------

local function CreateRow(panel)
    local row = CreateFrame("Button", nil, panel.ListArea)
    row:SetHeight(ROW_HEIGHT)
    row:SetHighlightTexture(Styles.Textures.listHighlight, "ADD")
    row:GetHighlightTexture():SetAlpha(0.3)

    row.Icon = row:CreateTexture(nil, "ARTWORK")
    row.Icon:SetSize(ICON_SIZE, ICON_SIZE)
    row.Icon:SetPoint("LEFT", 6, 0)

    row.Check = row:CreateTexture(nil, "ARTWORK")
    row.Check:SetSize(16, 16)
    row.Check:SetPoint("RIGHT", -8, 0)
    row.Check:SetTexture(DONE_CHECK)

    row.Status = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.Status:SetPoint("RIGHT", -8, 0)
    row.Status:SetJustifyH("RIGHT")

    row.Name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.Name:SetPoint("LEFT", row.Icon, "RIGHT", 6, 0)
    row.Name:SetPoint("RIGHT", row, "RIGHT", -120, 0)
    row.Name:SetJustifyH("LEFT")
    row.Name:SetWordWrap(false)

    row:SetScript("OnEnter", function(self)
        if self.data and self.data.kind == "item" then
            panel.callbacks.showTooltip(self.data.categoryKey, self.data.item, self)
        end
    end)
    row:SetScript("OnLeave", Styles.HideTooltip)
    return row
end

local function RenderHeader(row, data)
    row.Icon:Hide()
    row.Check:Hide()
    row.Name:SetFontObject("GameFontNormal")
    row.Name:SetText(data.label)
    row.Name:SetTextColor(NORMAL_FONT_COLOR:GetRGB())
    row.Status:ClearAllPoints()
    row.Status:SetPoint("RIGHT", -8, 0)
    row.Status:SetFontObject("GameFontHighlightSmall")
    row.Status:SetText(data.progress or "")
end

local function RenderNote(row, data)
    row.Icon:Hide()
    row.Check:Hide()
    row.Name:SetFontObject("GameFontDisableSmall")
    row.Name:SetText(data.label)
    row.Name:SetTextColor(GRAY_FONT_COLOR:GetRGB())
    row.Status:SetText("")
end

local function RenderItem(panel, row, data)
    local item = data.item
    local display = panel.callbacks.getDisplay(data.categoryKey, item)

    row.Icon:Show()
    row.Icon:SetTexture(display.icon)
    row.Icon:SetDesaturated(not item.counted)
    row.Name:SetFontObject("GameFontHighlight")
    row.Name:SetText(display.name or "Loading...")

    if not item.counted then
        row.Name:SetTextColor(GRAY_FONT_COLOR:GetRGB())
    elseif display.color then
        row.Name:SetTextColor(display.color:GetRGB())
    elseif item.done then
        row.Name:SetTextColor(HIGHLIGHT_FONT_COLOR:GetRGB())
    else
        row.Name:SetTextColor(NORMAL_FONT_COLOR:GetRGB())
    end

    -- Right column: why it isn't counted, otherwise how you get it.
    row.Check:SetShown(item.done)
    row.Status:ClearAllPoints()
    if item.done then
        row.Status:SetPoint("RIGHT", row.Check, "LEFT", -6, 0)
    else
        row.Status:SetPoint("RIGHT", -8, 0)
    end
    row.Status:SetFontObject("GameFontDisableSmall")
    if not item.counted then
        row.Status:SetText(REASON_LABELS[item.reason] or "Not counted")
    else
        row.Status:SetText(display.source or "")
    end
end

--------------------------------------------------------------------------------
-- Scrolling
--------------------------------------------------------------------------------

local PanelMethods = {}

function PanelMethods:GetVisibleRowCount()
    local height = self.ListArea:GetHeight()
    if not height or height <= 0 then
        return FALLBACK_VISIBLE_ROWS
    end
    return math.floor(height / ROW_HEIGHT)
end

function PanelMethods:Render()
    local visible = self:GetVisibleRowCount()
    local maxOffset = math.max(0, #self.rowsData - visible)
    self.offset = math.min(self.offset, maxOffset)

    self.Scroll:SetMinMaxValues(0, maxOffset)
    self.Scroll:SetShown(maxOffset > 0)
    if self.Scroll:GetValue() ~= self.offset then
        self.Scroll:SetValue(self.offset)
    end

    for index = 1, visible do
        local row = self.rows[index]
        if not row then
            row = CreateRow(self)
            row:SetPoint("TOPLEFT", self.ListArea, "TOPLEFT", 0, -(index - 1) * ROW_HEIGHT)
            row:SetPoint("TOPRIGHT", self.ListArea, "TOPRIGHT", 0, -(index - 1) * ROW_HEIGHT)
            self.rows[index] = row
        end
        local data = self.rowsData[self.offset + index]
        row.data = data
        if not data then
            row:Hide()
        else
            if data.kind == "header" then
                RenderHeader(row, data)
            elseif data.kind == "note" then
                RenderNote(row, data)
            else
                RenderItem(self, row, data)
            end
            row:Show()
        end
    end
    for index = visible + 1, #self.rows do
        self.rows[index]:Hide()
    end
end

function PanelMethods:ScrollBy(delta)
    self.offset = math.max(0, self.offset + delta)
    self:Render()
end

--------------------------------------------------------------------------------
-- Content
--------------------------------------------------------------------------------

-- Missing first, then done, then (only with "All") what isn't counted.
-- Items whose reason the player chose to hide are skipped; hiddenCount only
-- counts items this view would otherwise have shown.
local VIEW_GROUPS = {
    missing = { missing = true },
    done = { done = true },
    all = { missing = true, done = true, excluded = true },
}

local function GroupOf(item)
    if not item.counted then
        return "excluded"
    end
    return item.done and "done" or "missing"
end

local function SortedItems(items, filter, hiddenReasons)
    local groups = { missing = {}, done = {}, excluded = {} }
    local shownGroups = VIEW_GROUPS[filter] or VIEW_GROUPS.all
    local hiddenCount = 0
    for _, item in ipairs(items) do
        local group = GroupOf(item)
        if shownGroups[group] then
            if item.reason and hiddenReasons[item.reason] then
                hiddenCount = hiddenCount + 1
            else
                local list = groups[group]
                list[#list + 1] = item
            end
        end
    end
    local result = {}
    for _, group in ipairs({ "missing", "done", "excluded" }) do
        for _, item in ipairs(groups[group]) do result[#result + 1] = item end
    end
    return result, hiddenCount
end

local EMPTY_MESSAGES = {
    missing = "Nothing missing here - nice!",
    done = "Nothing done here yet.",
    all = "None in this zone.",
}

-- sections: { { key, label, completed, total, items } } (items nil = not available)
function PanelMethods:SetContent(title, subtitle, sections, filter)
    self.Title:SetText(title)
    self.Subtitle:SetText(subtitle or "")
    local hiddenReasons = self.callbacks.getHiddenReasons()
    self:UpdateReasonFilterButton(hiddenReasons)

    local rowsData = {}
    for _, section in ipairs(sections) do
        local progress = section.total and string.format("%d / %d", section.completed, section.total) or "--"
        rowsData[#rowsData + 1] = { kind = "header", label = section.label, progress = progress }
        if not section.items then
            rowsData[#rowsData + 1] = { kind = "note", label = "Not available." }
        else
            local items, hiddenCount = SortedItems(section.items, filter, hiddenReasons)
            if #section.items == 0 then
                rowsData[#rowsData + 1] = { kind = "note", label = EMPTY_MESSAGES.all }
            elseif #items == 0 then
                rowsData[#rowsData + 1] = { kind = "note", label = EMPTY_MESSAGES[filter] or EMPTY_MESSAGES.all }
            end
            for _, item in ipairs(items) do
                rowsData[#rowsData + 1] = { kind = "item", categoryKey = section.key, item = item }
            end
            if hiddenCount > 0 then
                rowsData[#rowsData + 1] = {
                    kind = "note",
                    label = string.format("%d hidden by the Filter button", hiddenCount),
                }
            end
        end
    end

    -- Keep the scroll position when only the data refreshed (same view).
    local viewKey = title .. "|" .. (subtitle or "") .. "|" .. filter
    if viewKey ~= self.viewKey then
        self.offset = 0
        self.viewKey = viewKey
    end
    self.rowsData = rowsData
    self:Render()
end

--------------------------------------------------------------------------------
-- Reason filter (which "not counted" items appear in the lists)
--------------------------------------------------------------------------------

local function CountHidden(hiddenReasons)
    local count = 0
    for _, reason in ipairs(ZC.Config.ExclusionReasons) do
        if hiddenReasons[reason.key] then count = count + 1 end
    end
    return count
end

function PanelMethods:UpdateReasonFilterButton(hiddenReasons)
    local hidden = CountHidden(hiddenReasons)
    self.ReasonButton:SetText(hidden > 0 and string.format("Filter (%d)", hidden) or "Filter")
    for _, check in ipairs(self.ReasonPopup.checks) do
        check:SetChecked(not hiddenReasons[check.reasonKey])
    end
end

-- A small bordered popup with one checkbox per reason: checked = shown.
local function CreateReasonPopup(panel)
    local popup = CreateFrame("Frame", nil, panel, "BackdropTemplate")
    popup:SetFrameStrata("DIALOG")
    popup:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    popup:SetBackdropColor(0, 0, 0, 0.92)
    popup:EnableMouse(true)
    popup:Hide()

    popup.Title = popup:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    popup.Title:SetPoint("TOPLEFT", 12, -10)
    popup.Title:SetText("Show items that are...")

    popup.checks = {}
    local y = -30
    for _, reason in ipairs(ZC.Config.ExclusionReasons) do
        local check = CreateFrame("CheckButton", nil, popup, "UICheckButtonTemplate")
        check:SetSize(22, 22)
        check:SetPoint("TOPLEFT", 8, y)
        check.reasonKey = reason.key
        check.Label = check:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        check.Label:SetPoint("LEFT", check, "RIGHT", 2, 1)
        check.Label:SetText(reason.label)
        check:SetHitRectInsets(0, -150, 0, 0)
        check:SetScript("OnClick", function(self)
            local shown = self:GetChecked() and true or false
            PlaySound(shown and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF)
            panel.callbacks.onReasonHiddenChanged(self.reasonKey, not shown)
        end)
        check:SetScript("OnEnter", function(self)
            Styles.ShowSimpleTooltip(self, reason.label, { { text = reason.note } })
        end)
        check:SetScript("OnLeave", Styles.HideTooltip)
        popup.checks[#popup.checks + 1] = check
        y = y - 22
    end

    local function SetAll(hidden)
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
        panel.callbacks.onAllReasonsHiddenChanged(hidden)
    end
    popup.CheckAll = CreateFrame("Button", nil, popup, "UIPanelButtonTemplate")
    popup.CheckAll:SetSize(88, 20)
    popup.CheckAll:SetPoint("TOPLEFT", 10, y - 6)
    popup.CheckAll:SetText("Check all")
    popup.CheckAll:SetScript("OnClick", function() SetAll(false) end)

    popup.UncheckAll = CreateFrame("Button", nil, popup, "UIPanelButtonTemplate")
    popup.UncheckAll:SetSize(88, 20)
    popup.UncheckAll:SetPoint("LEFT", popup.CheckAll, "RIGHT", 4, 0)
    popup.UncheckAll:SetText("Uncheck all")
    popup.UncheckAll:SetScript("OnClick", function() SetAll(true) end)

    popup:SetSize(200, -y + 40)

    -- Close when the player clicks anywhere outside the popup (clicks on the
    -- Filter button itself are left to its own toggle).
    popup:SetScript("OnShow", function(self) self:RegisterEvent("GLOBAL_MOUSE_DOWN") end)
    popup:SetScript("OnHide", function(self) self:UnregisterEvent("GLOBAL_MOUSE_DOWN") end)
    popup:SetScript("OnEvent", function(self)
        if not self:IsMouseOver() and not panel.ReasonButton:IsMouseOver() then
            self:Hide()
        end
    end)
    return popup
end

--------------------------------------------------------------------------------
-- Construction
--------------------------------------------------------------------------------

-- callbacks.getDisplay(categoryKey, item) -> { name, icon, color }
-- callbacks.showTooltip(categoryKey, item, owner)
-- callbacks.onFilterChanged(filterKey)
-- callbacks.getHiddenReasons() -> { [reasonKey] = true }
-- callbacks.onReasonHiddenChanged(reasonKey, hidden)
-- callbacks.onAllReasonsHiddenChanged(hidden)
function ItemList.CreatePanel(parent, callbacks)
    local panel = CreateFrame("Frame", nil, parent)
    panel.callbacks = callbacks
    panel.rows = {}
    panel.rowsData = {}
    panel.offset = 0

    panel.Title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    panel.Title:SetPoint("TOPLEFT", 16, -14)

    panel.Subtitle = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    panel.Subtitle:SetPoint("TOPLEFT", panel.Title, "BOTTOMLEFT", 0, -4)

    panel.Filter = ZC.UI.Navigation.CreateScopeToggle(panel, ZC.Config.ListFilters, function(filterKey)
        callbacks.onFilterChanged(filterKey)
    end, "Show:")
    panel.Filter:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -12, -14)

    panel.ReasonButton = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    panel.ReasonButton:SetSize(90, 22)
    panel.ReasonButton:SetPoint("RIGHT", panel.Filter.Label, "LEFT", -14, 0)
    panel.ReasonButton:SetText("Filter")
    panel.ReasonPopup = CreateReasonPopup(panel)
    panel.ReasonPopup:SetPoint("TOPRIGHT", panel.ReasonButton, "BOTTOMRIGHT", 0, -4)
    panel.ReasonButton:SetScript("OnClick", function()
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
        panel.ReasonPopup:SetShown(not panel.ReasonPopup:IsShown())
    end)
    panel.ReasonButton:SetScript("OnEnter", function(self)
        Styles.ShowSimpleTooltip(self, "Filter", {
            { text = "Choose which kinds of not-counted items appear in these lists." },
            { text = "Only changes the lists - totals follow \"Only count what this character can do\".", color = GRAY_FONT_COLOR },
        })
    end)
    panel.ReasonButton:SetScript("OnLeave", Styles.HideTooltip)
    panel:SetScript("OnHide", function() panel.ReasonPopup:Hide() end)

    panel.Divider = Styles.CreateDivider(panel)
    panel.Divider:SetPoint("TOPLEFT", 8, -46)
    panel.Divider:SetPoint("TOPRIGHT", -8, -46)

    panel.ListArea = CreateFrame("Frame", nil, panel)
    panel.ListArea:SetPoint("TOPLEFT", 8, -56)
    panel.ListArea:SetPoint("BOTTOMRIGHT", -26, 8)
    panel.ListArea:SetScript("OnSizeChanged", function() panel:Render() end)

    -- Mouse wheel anywhere over the list scrolls it.
    panel:EnableMouseWheel(true)
    panel:SetScript("OnMouseWheel", function(self, delta)
        self:ScrollBy(-delta * SCROLL_STEP)
    end)

    -- A plain vertical slider styled like Blizzard's classic scroll knob.
    local scroll = CreateFrame("Slider", nil, panel)
    scroll:SetOrientation("VERTICAL")
    scroll:SetWidth(16)
    scroll:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -6, -58)
    scroll:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -6, 10)
    scroll:SetThumbTexture("Interface\\Buttons\\UI-ScrollBar-Knob")
    scroll:GetThumbTexture():SetSize(18, 24)
    scroll:SetValueStep(1)
    scroll:SetObeyStepOnDrag(true)
    scroll:SetMinMaxValues(0, 0)
    local track = scroll:CreateTexture(nil, "BACKGROUND")
    track:SetColorTexture(0, 0, 0, 0.35)
    track:SetPoint("TOP")
    track:SetPoint("BOTTOM")
    track:SetWidth(6)
    scroll:SetScript("OnValueChanged", function(_, value)
        local offset = math.floor(value + 0.5)
        if offset ~= panel.offset then
            panel.offset = offset
            panel:Render()
        end
    end)
    panel.Scroll = scroll

    for name, method in pairs(PanelMethods) do
        panel[name] = method
    end
    return panel
end
