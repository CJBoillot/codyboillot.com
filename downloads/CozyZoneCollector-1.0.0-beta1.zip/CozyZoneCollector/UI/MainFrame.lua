-- MainFrame: the Zone Collector window. Owns layout and selection state and
-- is the only UI module that talks to the provider; child widgets receive
-- plain data tables.

local _, ZC = ...

local Styles = ZC.UI.Styles
local Config = ZC.Config

local MainFrame = {}
ZC.UI.MainFrame = MainFrame

-- A global frame name is required for UISpecialFrames (Escape to close) and
-- for Blizzard's PanelTemplates tab helpers.
local FRAME_NAME = "ZoneCollectorFrame"

-- Space reserved at the top for the portrait/title bar and the tagline row,
-- matching where Blizzard's ButtonFrameTemplate places its inset.
local CONTENT_TOP_OFFSET = -60
local COLUMN_GAP = 2

local TAB_ZONES = 1

local window
local selectedZoneID

local function GetScope()
    return (ZC.db and ZC.db.scope) or Config.DefaultScope
end

--------------------------------------------------------------------------------
-- Position (SavedVariables)
--------------------------------------------------------------------------------

local function SavePosition()
    if not ZC.db then
        return
    end
    local point, _, relativePoint, x, y = window:GetPoint(1)
    ZC.db.position = { point = point, relativePoint = relativePoint, x = x, y = y }
end

local function RestorePosition()
    window:ClearAllPoints()
    local saved = ZC.db and ZC.db.position
    if saved and saved.point then
        window:SetPoint(saved.point, UIParent, saved.relativePoint, saved.x, saved.y)
    else
        window:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
    end
end

--------------------------------------------------------------------------------
-- Frame chrome
--------------------------------------------------------------------------------

-- PortraitFrameTemplate exposes these through PortraitFrameMixin on Retail;
-- the fallbacks keep the window usable if a future client renames them.
local function SetWindowTitle(frame, text)
    if frame.SetTitle then
        frame:SetTitle(text)
    elseif frame.TitleText then
        frame.TitleText:SetText(text)
    end
end

local function SetWindowPortrait(frame, texture)
    if frame.SetPortraitToAsset then
        frame:SetPortraitToAsset(texture)
    end
end

-- Only the title strip starts a drag, like Blizzard's movable panels.
local function CreateDragRegion(frame)
    local region = CreateFrame("Frame", nil, frame)
    region:SetPoint("TOPLEFT", frame, "TOPLEFT", 58, 0)
    region:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -28, 0)
    region:SetHeight(24)
    region:EnableMouse(true)
    region:RegisterForDrag("LeftButton")
    region:SetScript("OnDragStart", function()
        frame:StartMoving()
    end)
    region:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
        -- We persist the position ourselves; keep the client's layout cache out of it.
        frame:SetUserPlaced(false)
        SavePosition()
    end)
end

local ELIGIBLE_TOOLTIP = {
    { text = "On: totals only include what this character can do." },
    { text = "Off: totals include everything still in the game - other classes, races and faction, holiday events and breadcrumb quests." },
    { text = "Either way, the line under the categories shows what was left out and why.", color = GRAY_FONT_COLOR },
}

local function CreateEligibleCheckbox(frame)
    local check = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
    check:SetSize(24, 24)
    check:SetPoint("TOPLEFT", frame, "TOPLEFT", 60, -30)

    check.Label = check:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    check.Label:SetPoint("LEFT", check, "RIGHT", 2, 1)
    check.Label:SetText("Only count what this character can do")
    -- Let the label be clicked too, like Blizzard's option checkboxes.
    check:SetHitRectInsets(0, -(check.Label:GetStringWidth() + 6), 0, 0)

    check:SetScript("OnClick", function(self)
        local enabled = self:GetChecked() and true or false
        PlaySound(enabled and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF)
        ZC:SetEligibleOnly(enabled)
        MainFrame:Refresh()
    end)
    check:SetScript("OnEnter", function(self)
        Styles.ShowSimpleTooltip(self, "Only count what this character can do", ELIGIBLE_TOOLTIP)
    end)
    check:SetScript("OnLeave", Styles.HideTooltip)
    return check
end

--------------------------------------------------------------------------------
-- Action bar macro: a one-click "/zc" button for the player's hotbar.
--------------------------------------------------------------------------------

local MACRO_NAME = Config.MacroName
local MACRO_BODY = "/zc"
local MACRO_ICON = "INV_Misc_Map_01"
local MACRO_ICON_PATH = "Interface\\Icons\\INV_Misc_Map_01"
local DEFAULT_ACCOUNT_MACRO_LIMIT = 120

-- Reuses the macro if it already exists so repeated drags don't pile up copies.
local function GetOrCreateMacro()
    local index = GetMacroIndexByName(MACRO_NAME)
    if index and index > 0 then
        return index
    end

    local accountMacros = GetNumMacros()
    if accountMacros >= (MAX_ACCOUNT_MACROS or DEFAULT_ACCOUNT_MACRO_LIMIT) then
        return nil, "Your account-wide macro slots are full - delete one in /macro and try again."
    end

    -- CreateMacro accepts an icon name; fall back to the file ID if needed.
    local ok, created = pcall(CreateMacro, MACRO_NAME, MACRO_ICON, MACRO_BODY, false)
    if (not ok or not created) and GetFileIDFromPath then
        ok, created = pcall(CreateMacro, MACRO_NAME, GetFileIDFromPath(MACRO_ICON_PATH), MACRO_BODY, false)
    end
    if ok and created then
        return created
    end
    return nil, "Couldn't create the macro - you can make one yourself in /macro with the text /zc."
end

-- Puts the macro on the cursor, ready to drop onto an action bar.
function MainFrame:PickupMacro()
    if InCombatLockdown() then
        ZC:Print("Macros can't be created during combat - try again after the fight.")
        return
    end
    local index, problem = GetOrCreateMacro()
    if not index then
        ZC:Print(problem)
        return
    end
    PickupMacro(index)
end

local MACRO_TOOLTIP = {
    { text = "Drag this icon onto an action bar to open Cozy Zone Collector with one click." },
    { text = "Creates an account-wide macro named \"" .. MACRO_NAME .. "\" that runs /zc.", color = GRAY_FONT_COLOR },
}

local HOTBAR_ICON_SIZE = 40

-- Bottom of the left column: "Drag to Hotbar" over the addon icon, styled
-- like an action button. Dragging (or clicking) it picks up the macro.
-- Note: the macro on the bar shows a game icon - WoW macros can only use
-- the game's own icons, not textures shipped with an addon.
local function CreateHotbarSection(sidebar)
    local section = CreateFrame("Frame", nil, sidebar)
    section:SetPoint("BOTTOMLEFT", 4, 26)
    section:SetPoint("BOTTOMRIGHT", -4, 26)
    section:SetHeight(76)

    section.Divider = Styles.CreateDivider(section)
    section.Divider:SetPoint("TOPLEFT", 0, 0)
    section.Divider:SetPoint("TOPRIGHT", 0, 0)

    section.Label = section:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    section.Label:SetPoint("TOP", 0, -10)
    section.Label:SetText("Drag to Hotbar")

    local button = CreateFrame("Button", nil, section)
    button:SetSize(HOTBAR_ICON_SIZE, HOTBAR_ICON_SIZE)
    button:SetPoint("TOP", section.Label, "BOTTOM", 0, -6)
    button:RegisterForDrag("LeftButton")

    button.Icon = button:CreateTexture(nil, "ARTWORK")
    button.Icon:SetAllPoints()
    button.Icon:SetTexture(Styles.Textures.brandIcon)

    -- Same proportions as an action button's 66px frame around a 36px icon.
    button.Border = button:CreateTexture(nil, "OVERLAY")
    button.Border:SetTexture(Styles.Textures.actionBorder)
    button.Border:SetSize(HOTBAR_ICON_SIZE * 66 / 36, HOTBAR_ICON_SIZE * 66 / 36)
    button.Border:SetPoint("CENTER", button, "CENTER", 0, 0)

    button:SetHighlightTexture(Styles.Textures.actionHighlight, "ADD")

    local function Pickup()
        GameTooltip:Hide()
        MainFrame:PickupMacro()
    end
    button:SetScript("OnDragStart", Pickup)
    button:SetScript("OnClick", Pickup)
    button:SetScript("OnEnter", function(self)
        Styles.ShowSimpleTooltip(self, "Drag to Hotbar", MACRO_TOOLTIP)
    end)
    button:SetScript("OnLeave", Styles.HideTooltip)

    section.Button = button
    return section
end

--------------------------------------------------------------------------------
-- "Current Zone" button
--------------------------------------------------------------------------------

local CURRENT_ZONE_TOOLTIP = {
    { text = "Jump to the zone you're standing in." },
}

local function CreateCurrentZoneButton(parent)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetSize(96, 20)
    button:SetText("Current Zone")
    button:SetNormalFontObject("GameFontNormalSmall")
    button:SetHighlightFontObject("GameFontHighlightSmall")
    button:SetScript("OnClick", function()
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
        MainFrame:SelectCurrentZone()
    end)
    button:SetScript("OnEnter", function(self)
        Styles.ShowSimpleTooltip(self, "Current Zone", CURRENT_ZONE_TOOLTIP)
    end)
    button:SetScript("OnLeave", Styles.HideTooltip)
    return button
end

local AUTO_SWITCH_TOOLTIP = {
    { text = "When you enter a new zone, switch every tab to it." },
    { text = "If the window is closed, it opens on that zone next time.", color = GRAY_FONT_COLOR },
}

local function CreateAutoSwitchCheckbox(frame)
    local check = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
    check:SetSize(22, 22)

    check.Label = check:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    check.Label:SetPoint("LEFT", check, "RIGHT", 1, 1)
    check.Label:SetText("Auto-switch zone")
    check:SetHitRectInsets(0, -(check.Label:GetStringWidth() + 4), 0, 0)

    check:SetScript("OnClick", function(self)
        local enabled = self:GetChecked() and true or false
        PlaySound(enabled and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF)
        ZC:SetAutoSwitchZone(enabled)
        if enabled then
            MainFrame:FollowPlayerZone() -- jump there right away
        end
    end)
    check:SetScript("OnEnter", function(self)
        Styles.ShowSimpleTooltip(self, "Auto-switch zone", AUTO_SWITCH_TOOLTIP)
    end)
    check:SetScript("OnLeave", Styles.HideTooltip)
    return check
end

local function CreateHeaderRow(frame)
    frame.EligibleCheck = CreateEligibleCheckbox(frame)

    frame.DataNotice = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.DataNotice:SetPoint("LEFT", frame.EligibleCheck.Label, "RIGHT", 12, 0)

    frame.ScopeToggle = ZC.UI.Navigation.CreateScopeToggle(frame, Config.Scopes, function(scope)
        MainFrame:SetScope(scope)
    end)
    frame.ScopeToggle:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -12, -31)

    -- One button for every tab, just left of "View:".
    frame.CurrentZoneButton = CreateCurrentZoneButton(frame)
    frame.CurrentZoneButton:SetPoint("RIGHT", frame.ScopeToggle.Label, "LEFT", -14, 0)

    -- [x] Auto-switch zone, left of Current Zone (label sits to its right).
    frame.AutoSwitchCheck = CreateAutoSwitchCheckbox(frame)
    frame.AutoSwitchCheck:SetPoint("RIGHT", frame.CurrentZoneButton, "LEFT",
        -(frame.AutoSwitchCheck.Label:GetStringWidth() + 12), 0)

    -- "Alliance zone" / "Horde zone - not for you"; kept clear of the
    -- controls on the right (long text is cut off rather than overlapping).
    frame.FactionBanner = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    frame.FactionBanner:SetPoint("LEFT", frame.EligibleCheck.Label, "RIGHT", 24, 0)
    frame.FactionBanner:SetPoint("RIGHT", frame.AutoSwitchCheck, "LEFT", -10, 0)
    frame.FactionBanner:SetJustifyH("LEFT")
    frame.FactionBanner:SetWordWrap(false)
end

--------------------------------------------------------------------------------
-- Faction theme: faction zones tint every panel background and show a banner.
--------------------------------------------------------------------------------

local FACTION_THEME = {
    [2] = { name = "Alliance", tint = { 0.10, 0.25, 0.85, 0.22 }, text = "ff4a8cff" }, -- royal blue
    [1] = { name = "Horde",    tint = { 0.80, 0.06, 0.06, 0.20 }, text = "ffff4040" }, -- Horde red
}

-- A colour wash over an inset's background, under its content.
local function AddTint(frame, inset)
    local tint = inset:CreateTexture(nil, "BORDER", nil, -7)
    tint:SetPoint("TOPLEFT", 3, -3)
    tint:SetPoint("BOTTOMRIGHT", -3, 3)
    tint:Hide()
    frame.Tints[#frame.Tints + 1] = tint
end

local function ApplyFactionTheme(frame, zoneFaction, playerFaction)
    local theme = zoneFaction and FACTION_THEME[zoneFaction]
    for _, tint in ipairs(frame.Tints) do
        if theme then
            tint:SetColorTexture(theme.tint[1], theme.tint[2], theme.tint[3], theme.tint[4])
            tint:Show()
        else
            tint:Hide()
        end
    end

    if not theme then
        frame.FactionBanner:SetText("")
    elseif playerFaction and zoneFaction ~= playerFaction then
        frame.FactionBanner:SetText(string.format("|c%s%s zone|r  |cffbbbbbb- not for you|r",
            theme.text, theme.name))
    else
        frame.FactionBanner:SetText(string.format("|c%s%s zone|r", theme.text, theme.name))
    end
end

--------------------------------------------------------------------------------
-- Tab panels
--------------------------------------------------------------------------------

-- Continents start collapsed except the first (Eastern Kingdoms): with
-- every expansion listed, counting only what's open keeps refreshes fast.
-- Continents the player hasn't seen before (first run, or newly added in
-- an update) also start collapsed.
local function GetCollapsedContinents()
    if not ZC.db then
        return {}
    end
    local firstRun = ZC.db.collapsedContinents == nil
    ZC.db.collapsedContinents = ZC.db.collapsedContinents or {}
    ZC.db.knownContinents = ZC.db.knownContinents or {}
    local collapsed, known = ZC.db.collapsedContinents, ZC.db.knownContinents
    for index, continent in ipairs(ZC.Data.Continents) do
        if not known[continent.id] then
            known[continent.id] = true
            if not (firstRun and index == 1) and not (continent.id == 13 or continent.id == 12) then
                collapsed[continent.id] = true
            end
        end
    end
    return collapsed
end

local function AnchorTabContent(panel, frame)
    panel:SetPoint("TOPLEFT", frame, "TOPLEFT", 4, CONTENT_TOP_OFFSET)
    panel:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -6, 4)
end

-- Home screen: the main zone list (left), zone overview (centre) and
-- region summary (right).
local function CreateZonesPanel(frame)
    local panel = CreateFrame("Frame", nil, frame)
    AnchorTabContent(panel, frame)

    local sidebar = CreateFrame("Frame", nil, panel, "InsetFrameTemplate")
    sidebar:SetPoint("TOPLEFT")
    sidebar:SetPoint("BOTTOMLEFT")
    sidebar:SetWidth(Config.Window.sidebarWidth)
    AddTint(frame, sidebar)

    local summary = CreateFrame("Frame", nil, panel, "InsetFrameTemplate")
    summary:SetPoint("TOPRIGHT")
    summary:SetPoint("BOTTOMRIGHT")
    summary:SetWidth(Config.Window.summaryWidth)
    AddTint(frame, summary)

    local center = CreateFrame("Frame", nil, panel, "InsetFrameTemplate")
    center:SetPoint("TOPLEFT", sidebar, "TOPRIGHT", COLUMN_GAP, 0)
    center:SetPoint("BOTTOMRIGHT", summary, "BOTTOMLEFT", -COLUMN_GAP, 0)
    AddTint(frame, center)

    panel.HotbarSection = CreateHotbarSection(sidebar)

    panel.Tagline = sidebar:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    panel.Tagline:SetPoint("BOTTOM", sidebar, "BOTTOM", 0, 10)
    panel.Tagline:SetText("Finish Azeroth one zone at a time.")

    panel.ZoneList = ZC.UI.Navigation.CreateZoneList(sidebar, function(zoneID)
        MainFrame:SelectZone(zoneID)
    end, GetCollapsedContinents(), function()
        MainFrame:Refresh() -- a continent was opened: count its zones
    end)
    panel.ZoneList:SetPoint("TOPLEFT", 4, -4)
    panel.ZoneList:SetPoint("BOTTOMRIGHT", panel.HotbarSection, "TOPRIGHT", 0, 4)

    panel.Overview = ZC.UI.ZoneOverview.Create(center)
    panel.Overview:SetAllPoints()

    panel.Summary = ZC.UI.RegionSummary.Create(summary)
    panel.Summary:SetAllPoints()

    return panel
end

local function GetListFilter()
    return (ZC.db and ZC.db.listFilter) or Config.DefaultListFilter
end

-- In a zone that belongs to the other faction, "Other faction" items are
-- the zone's content, so they're shown (greyed, tagged) even if that
-- reason is hidden by the Filter button.
local function GetEffectiveHiddenReasons()
    local hidden = ZC:GetHiddenReasons()
    local zone = selectedZoneID and ZC.Data.Zones[selectedZoneID]
    local playerFaction = ZC:GetProvider():GetPlayerFactionID()
    if zone and zone.faction and playerFaction and zone.faction ~= playerFaction and hidden.faction then
        local copy = {}
        for reason, value in pairs(hidden) do copy[reason] = value end
        copy.faction = nil
        return copy
    end
    return hidden
end

-- Item-list tabs: a zone picker at the top, then the list.
local function CreateListTabPanel(frame, tab)
    local inset = CreateFrame("Frame", nil, frame, "InsetFrameTemplate")
    AnchorTabContent(inset, frame)
    AddTint(frame, inset)
    inset.tab = tab

    inset.List = ZC.UI.ItemList.CreatePanel(inset, {
        getDisplay = function(categoryKey, item)
            return ZC:GetProvider():GetItemDisplay(categoryKey, item)
        end,
        showTooltip = function(categoryKey, item, owner)
            ZC:GetProvider():ShowItemTooltip(categoryKey, item, owner)
        end,
        getHiddenReasons = GetEffectiveHiddenReasons,
        onReasonHiddenChanged = function(reasonKey, hidden)
            ZC:SetReasonHidden(reasonKey, hidden)
            MainFrame:UpdateListTab()
        end,
        onAllReasonsHiddenChanged = function(hidden)
            for _, reason in ipairs(Config.ExclusionReasons) do
                ZC:SetReasonHidden(reason.key, hidden)
            end
            MainFrame:UpdateListTab()
        end,
        onFilterChanged = function(filterKey)
            if ZC.db then
                ZC.db.listFilter = filterKey
            end
            MainFrame:UpdateListTab()
        end,
    })
    inset.List:SetAllPoints()

    inset.ZonePicker = ZC.UI.Navigation.CreateZonePicker(inset.List, function(zoneID)
        MainFrame:SelectZone(zoneID)
    end, GetCollapsedContinents(), function()
        MainFrame:Refresh()
    end)
    inset.ZonePicker:SetPoint("LEFT", inset.List.Title, "RIGHT", 16, 0)
    return inset
end

--------------------------------------------------------------------------------
-- Construction
--------------------------------------------------------------------------------

local function CreateWindow()
    local frame = CreateFrame("Frame", FRAME_NAME, UIParent, "PortraitFrameTemplate")
    frame:Hide()
    frame:SetSize(Config.Window.width, Config.Window.height)
    frame:SetToplevel(true)
    frame:EnableMouse(true)
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)

    SetWindowTitle(frame, "Cozy Zone Collector")
    SetWindowPortrait(frame, Styles.Textures.portrait)
    CreateDragRegion(frame)
    CreateHeaderRow(frame)

    frame.Tints = {}
    frame.Panels = {}
    for index, tab in ipairs(Config.Tabs) do
        if index == TAB_ZONES then
            frame.Panels[index] = CreateZonesPanel(frame)
        else
            frame.Panels[index] = CreateListTabPanel(frame, tab)
        end
    end
    frame.ZonesPanel = frame.Panels[TAB_ZONES]
    frame.ZoneList = frame.ZonesPanel.ZoneList

    ZC.UI.Navigation.CreateTabs(frame, Config.Tabs, function(tabIndex)
        MainFrame:SelectTab(tabIndex)
    end)

    frame:SetScript("OnShow", function()
        PlaySound(SOUNDKIT.IG_CHARACTER_INFO_OPEN)
        MainFrame:Refresh()
    end)
    frame:SetScript("OnHide", function()
        PlaySound(SOUNDKIT.IG_CHARACTER_INFO_CLOSE)
    end)

    table.insert(UISpecialFrames, FRAME_NAME)
    return frame
end

local function EnsureWindow()
    if not window then
        window = CreateWindow()
        RestorePosition()
        MainFrame:SelectTab(TAB_ZONES)
    end
    return window
end

--------------------------------------------------------------------------------
-- Public API
--------------------------------------------------------------------------------

function MainFrame:Toggle()
    if not ZC:GetProvider() then
        ZC:Print("Not ready yet - no data provider is active.")
        return
    end
    local frame = EnsureWindow()
    frame:SetShown(not frame:IsShown())
end

function MainFrame:RefreshIfShown()
    if window and window:IsShown() then
        self:Refresh()
    end
end

function MainFrame:ResetPosition()
    if ZC.db then
        ZC.db.position = nil
    end
    if window then
        RestorePosition()
    end
end

function MainFrame:SetScope(scope)
    if ZC.db then
        ZC.db.scope = scope
    end
    if window then
        self:Refresh()
    end
end

function MainFrame:SelectTab(tabIndex)
    window.selectedTab = tabIndex
    PanelTemplates_SetTab(window, tabIndex)
    for index, panel in ipairs(window.Panels) do
        panel:SetShown(index == tabIndex)
    end
    if window:IsShown() then
        self:UpdateListTab()
    end
end

-- Fills the visible item-list tab for the selected zone. Does nothing on
-- the Zones tab.
function MainFrame:UpdateListTab()
    self:UpdateListPanel(window.Panels[window.selectedTab or TAB_ZONES])
end

-- Every item-list tab, visible or not, so they all show the selected zone.
function MainFrame:UpdateAllListTabs()
    for _, panel in ipairs(window.Panels) do
        self:UpdateListPanel(panel)
    end
end

function MainFrame:UpdateListPanel(panel)
    if not panel or not panel.tab or not panel.tab.sections then
        return
    end
    local provider = ZC:GetProvider()
    local scope = GetScope()

    local sections = {}
    for _, categoryKey in ipairs(panel.tab.sections) do
        local category = provider:GetCategory(categoryKey)
        if category then
            local items = selectedZoneID and provider:GetCategoryItems(selectedZoneID, categoryKey, scope)
            local completed, total = nil, nil
            if items then
                completed, total = 0, 0
                for _, item in ipairs(items) do
                    if item.counted then
                        total = total + 1
                        if item.done then completed = completed + 1 end
                    end
                end
            end
            sections[#sections + 1] = {
                key = categoryKey, label = category.label, items = items, completed = completed, total = total,
            }
        end
    end

    local filter = GetListFilter()
    panel.List.Filter:SetSelected(filter)
    panel.ZonePicker:SetZone(selectedZoneID and provider:GetZoneName(selectedZoneID))
    panel.ZonePicker:SetSections(self.zoneSections or {}, selectedZoneID)
    local subtitle = ""
    if provider.isMock then
        subtitle = "|cff808080(item lists aren't available with mock data)|r"
    end
    panel.List:SetContent(panel.tab.label, subtitle, sections, filter)
end

-- Names/icons arrived: repaint the visible rows only.
function MainFrame:RedrawLists()
    local panel = window and window:IsShown() and window.Panels[window.selectedTab or TAB_ZONES]
    if panel and panel.List then
        panel.List:Render()
    end
end

-- Rebuilds the zone lists from the provider and re-applies the selection.
-- The selected zone survives /reload via ZC.db.selectedZoneID; if that zone
-- is no longer listed, the first listed zone is used instead.
function MainFrame:Refresh()
    local provider = ZC:GetProvider()
    provider:ClearCache()
    local scope = GetScope()
    local sections = {}
    local preferredZoneID = selectedZoneID or (ZC.db and ZC.db.selectedZoneID)
    local firstZoneID, preferredFound

    local collapsed = GetCollapsedContinents()
    for _, continent in ipairs(provider:GetContinents()) do
        local zones = {}
        for _, zone in ipairs(provider:GetZones(continent.id)) do
            -- Collapsed continents aren't shown, so their zones aren't counted.
            local data = not collapsed[continent.id] and provider:GetZoneData(zone.id, scope)
            zones[#zones + 1] = {
                id = zone.id,
                name = zone.name,
                faction = zone.faction,
                completion = data and data.completion,
            }
            firstZoneID = firstZoneID or zone.id
            preferredFound = preferredFound or zone.id == preferredZoneID
        end
        sections[#sections + 1] = { continent = continent, zones = zones }
    end
    self.zoneSections = sections

    window.DataNotice:SetText(provider.isMock and "(development build - mock data)" or "")
    window.ScopeToggle:SetSelected(scope)
    window.EligibleCheck:SetChecked(ZC:IsEligibleOnly())
    window.AutoSwitchCheck:SetChecked(ZC:IsAutoSwitchZone())
    window.ZoneList:SetSections(sections)
    self.refreshing = true
    self:SelectZone(preferredFound and preferredZoneID or firstZoneID)
    self.refreshing = false
    -- Bring the selection into view once, not on every refresh (e.g. after
    -- opening a continent further down the list).
    if self.scrolledToZoneID ~= selectedZoneID then
        window.ZoneList:ScrollToSelected()
        self.scrolledToZoneID = selectedZoneID
    end
end

-- Auto-switch: called when the player enters a new zone (and when the
-- checkbox is ticked). Unlisted places (dungeons, etc.) are ignored quietly.
function MainFrame:FollowPlayerZone()
    if not ZC:IsAutoSwitchZone() or not ZC:GetProvider() then
        return
    end
    local zoneID = ZC:GetProvider():GetCurrentZone()
    if not zoneID or zoneID == selectedZoneID then
        return
    end
    if window and window:IsShown() then
        self:SelectZone(zoneID)
    else
        -- Remembered for the next time the window opens.
        selectedZoneID = zoneID
        self.scrolledToZoneID = nil
        if ZC.db then
            ZC.db.selectedZoneID = zoneID
            local zone = ZC.Data.Zones[zoneID]
            if zone then
                GetCollapsedContinents()[zone.continentID] = nil
            end
        end
    end
end

local zoneEvents = CreateFrame("Frame")
zoneEvents:RegisterEvent("ZONE_CHANGED_NEW_AREA")
zoneEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
zoneEvents:SetScript("OnEvent", function()
    MainFrame:FollowPlayerZone()
end)

-- Selects the zone the player is in, opening its continent in the list.
function MainFrame:SelectCurrentZone()
    local provider = ZC:GetProvider()
    local zoneID, hereName = provider:GetCurrentZone()
    if not zoneID then
        ZC:Print(string.format("%s isn't in the zone list.", hereName or "This place"))
        return
    end
    self:SelectZone(zoneID)
end

-- The one place a zone gets selected (zone list, zone pickers, Current
-- Zone): every tab follows, and the zone list opens the zone's continent
-- and scrolls to it.
function MainFrame:SelectZone(zoneID)
    selectedZoneID = zoneID
    if ZC.db then
        ZC.db.selectedZoneID = zoneID
    end

    local zone = zoneID and ZC.Data.Zones[zoneID]
    local collapsed = GetCollapsedContinents()
    if zone and collapsed[zone.continentID] and not self.refreshing then
        collapsed[zone.continentID] = nil
        self.scrolledToZoneID = nil
        self:Refresh() -- counts the newly opened continent, then selects again
        return
    end
    local provider = ZC:GetProvider()
    local panel = window.ZonesPanel
    local scope = GetScope()

    local data = zoneID and provider:GetZoneData(zoneID, scope)
    local continent = data and provider:GetContinent(data.continentID)
    local continentName = continent and continent.name

    window.ZoneList:SetSelected(zoneID)
    ApplyFactionTheme(window, data and data.faction, provider:GetPlayerFactionID())
    panel.Overview:SetZone(data, continentName)
    panel.Summary:SetRegion(continent and provider:GetRegionSummary(continent.id, scope), continentName, scope)
    self:UpdateAllListTabs()

    if not self.refreshing and self.scrolledToZoneID ~= zoneID then
        window.ZoneList:ScrollToSelected()
        self.scrolledToZoneID = zoneID
    end
end
