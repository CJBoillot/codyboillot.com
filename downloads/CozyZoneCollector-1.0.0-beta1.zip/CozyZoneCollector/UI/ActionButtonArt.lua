-- ActionButtonArt: shows the addon's own artwork on action bar buttons that
-- hold the "Cozy Zones" macro.
--
-- Why: WoW macros can only use the game's built-in icons, so the macro
-- itself carries a map icon. Blizzard's action buttons redraw their icon
-- in their Update method; we hook that and, for our macro only, swap the
-- icon texture for Media/CZC_Icon and hide the macro's name label.
-- Only the textures change - the button's secure click behaviour is
-- untouched - so this is safe in and out of combat.
--
-- Covers Blizzard's own bars. Replacement bar addons (Bartender, Dominos,
-- ElvUI...) draw their own buttons and keep showing the macro's icon.

local _, ZC = ...

local Styles = ZC.UI.Styles

local ActionButtonArt = {}
ZC.UI.ActionButtonArt = ActionButtonArt

local BAR_BUTTON_PREFIXES = {
    "ActionButton",
    "MultiBarBottomLeftButton",
    "MultiBarBottomRightButton",
    "MultiBarRightButton",
    "MultiBarLeftButton",
    "MultiBar5Button",
    "MultiBar6Button",
    "MultiBar7Button",
}
local BUTTONS_PER_BAR = NUM_ACTIONBAR_BUTTONS or 12

local hookedButtons = {}

local function GetSlot(button)
    return button.action or (button.GetAttribute and button:GetAttribute("action"))
end

local function HoldsOurMacro(slot)
    if not slot or not HasAction(slot) then
        return false
    end
    local actionType = GetActionInfo(slot)
    return actionType == "macro" and GetActionText(slot) == ZC.Config.MacroName
end

-- Runs after Blizzard's own Update, so Blizzard has already drawn the
-- normal icon; we only overwrite it for our macro.
local function ApplyArt(button)
    local icon = button.icon or button.Icon
    if not icon then
        return
    end
    if HoldsOurMacro(GetSlot(button)) then
        icon:SetTexture(Styles.Textures.brandIcon)
        if button.Name then
            button.Name:SetText("")
        end
    end
end

local function HookButton(button)
    if not button or hookedButtons[button] then
        return
    end
    hookedButtons[button] = true
    if type(button.Update) == "function" then
        hooksecurefunc(button, "Update", ApplyArt)
    end
    ApplyArt(button)
end

function ActionButtonArt:RefreshAll()
    for _, prefix in ipairs(BAR_BUTTON_PREFIXES) do
        for index = 1, BUTTONS_PER_BAR do
            local button = _G[prefix .. index]
            if button then
                HookButton(button)
                ApplyArt(button)
            end
        end
    end
end

-- Bar contents change on these; re-check after Blizzard has updated.
local REFRESH_EVENTS = {
    "PLAYER_ENTERING_WORLD",
    "ACTIONBAR_SLOT_CHANGED",
    "ACTIONBAR_PAGE_CHANGED",
    "UPDATE_BONUS_ACTIONBAR",
    "UPDATE_MACROS",
}

local eventFrame = CreateFrame("Frame")
for _, event in ipairs(REFRESH_EVENTS) do
    pcall(eventFrame.RegisterEvent, eventFrame, event)
end
eventFrame:SetScript("OnEvent", function()
    C_Timer.After(0, function()
        ActionButtonArt:RefreshAll()
    end)
end)
