-- Shared look-and-feel helpers. Everything visual that is reused lives here
-- so the panels stay consistent and textures are chosen in one place.

local addonName, ZC = ...

local Styles = {}
ZC.UI.Styles = Styles

Styles.Textures = {
    statusBar   = "Interface\\TargetingFrame\\UI-StatusBar",
    barBorder   = "Interface\\Tooltips\\UI-Tooltip-Border",
    divider     = "Interface\\Common\\UI-TooltipDivider-Transparent",
    listHighlight = "Interface\\Buttons\\UI-Listbox-Highlight2",
    listSelected  = "Interface\\Buttons\\UI-Listbox-Highlight",
    -- The addon's own artwork (Media/CZC_Icon.tga, 128x128).
    -- Built from the addon's folder name so the art loads whatever the
    -- folder is called (ZoneCollector while developing, CozyZoneCollector
    -- in releases).
    brandIcon   = "Interface\\AddOns\\" .. addonName .. "\\Media\\CZC_Icon",
    portrait    = "Interface\\AddOns\\" .. addonName .. "\\Media\\CZC_Icon",
    actionBorder    = "Interface\\Buttons\\UI-Quickslot2",
    actionHighlight = "Interface\\Buttons\\ButtonHilight-Square",
}

-- Blizzard-like bar fills: green while in progress, gold when complete.
local BAR_IN_PROGRESS = { 0.10, 0.62, 0.10 }
local BAR_COMPLETE    = { 1.00, 0.78, 0.10 }

-- Prefer a modern atlas when the client has it, otherwise fall back to a
-- long-standing texture file, so a renamed atlas never shows a green box.
-- Returns true when the atlas was used.
function Styles.SetAtlasOrFile(texture, atlas, file)
    if atlas and C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo(atlas) then
        texture:SetAtlas(atlas)
        return true
    end
    texture:SetTexture(file)
    return false
end

function Styles.FormatPercent(percent)
    if not percent then
        return "--"
    end
    return string.format("%d%%", math.floor(percent))
end

-- Returns r, g, b for a completion percentage label.
function Styles.PercentColor(percent)
    if not percent then
        return DISABLED_FONT_COLOR:GetRGB()
    elseif percent >= 100 then
        return NORMAL_FONT_COLOR:GetRGB()
    elseif percent <= 0 then
        return GRAY_FONT_COLOR:GetRGB()
    end
    return HIGHLIGHT_FONT_COLOR:GetRGB()
end

function Styles.CreateDivider(parent)
    local divider = parent:CreateTexture(nil, "ARTWORK")
    divider:SetTexture(Styles.Textures.divider)
    divider:SetHeight(8)
    return divider
end

-- A StatusBar with a dark background and a thin tooltip-style border.
-- `showText` adds a centered label on top of the fill.
function Styles.CreateProgressBar(parent, height, showText)
    local bar = CreateFrame("StatusBar", nil, parent)
    bar:SetHeight(height)
    bar:SetStatusBarTexture(Styles.Textures.statusBar)
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(0)

    local background = bar:CreateTexture(nil, "BACKGROUND")
    background:SetAllPoints()
    background:SetColorTexture(0, 0, 0, 0.55)

    local border = CreateFrame("Frame", nil, bar, "BackdropTemplate")
    local inset = height >= 12 and 4 or 3
    border:SetPoint("TOPLEFT", -inset, inset)
    border:SetPoint("BOTTOMRIGHT", inset, -inset)
    border:SetBackdrop({ edgeFile = Styles.Textures.barBorder, edgeSize = height >= 12 and 12 or 8 })
    border:SetBackdropBorderColor(0.55, 0.55, 0.55, 1)
    bar.Border = border

    if showText then
        bar.Text = border:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        bar.Text:SetPoint("CENTER", bar, "CENTER", 0, 0)
    end

    return bar
end

-- fraction: 0..1, or nil to show an empty "unknown" bar.
function Styles.SetBarFraction(bar, fraction, label)
    local color = BAR_IN_PROGRESS
    if fraction and fraction >= 1 then
        color = BAR_COMPLETE
    end
    bar:SetStatusBarColor(color[1], color[2], color[3])
    bar:SetValue(fraction or 0)
    if bar.Text then
        bar.Text:SetText(label or "")
    end
end

-- lines: { text, color?, right?, rightColor? }. A line with `right` is
-- drawn as two columns (label left, value right), like Blizzard's stat
-- tooltips; other lines wrap.
function Styles.ShowSimpleTooltip(owner, title, lines)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:SetText(title, NORMAL_FONT_COLOR:GetRGB())
    for _, line in ipairs(lines or {}) do
        local r, g, b = HIGHLIGHT_FONT_COLOR:GetRGB()
        if line.color then
            r, g, b = line.color:GetRGB()
        end
        if line.right then
            local rr, rg, rb = HIGHLIGHT_FONT_COLOR:GetRGB()
            if line.rightColor then
                rr, rg, rb = line.rightColor:GetRGB()
            end
            GameTooltip:AddDoubleLine(line.text, line.right, r, g, b, rr, rg, rb)
        else
            GameTooltip:AddLine(line.text, r, g, b, true)
        end
    end
    GameTooltip:Show()
end

-- Appends a compact "Not counted" breakdown: one row per reason, count on
-- the right. `excluded` = { [reasonKey] = count }.
function Styles.AddExclusionLines(lines, excluded)
    if not excluded or not next(excluded) then
        return
    end
    lines[#lines + 1] = { text = " " }
    lines[#lines + 1] = { text = "Not counted", color = NORMAL_FONT_COLOR }
    for _, reason in ipairs(ZC.Config.ExclusionReasons) do
        local count = excluded[reason.key]
        if count and count > 0 then
            lines[#lines + 1] = { text = reason.label, color = GRAY_FONT_COLOR, right = tostring(count) }
        end
    end
end

function Styles.HideTooltip()
    GameTooltip:Hide()
end
