-- Navigation: the main panel tabs and the continent/zone sidebar.
-- Neither widget knows where its data comes from; MainFrame feeds them.

local _, ZC = ...

local Styles = ZC.UI.Styles

local Navigation = {}
ZC.UI.Navigation = Navigation

--------------------------------------------------------------------------------
-- Tabs
--------------------------------------------------------------------------------

-- Blizzard's PanelTemplates_* helpers look tabs up through frame.Tabs (and,
-- on older code paths, by the global name "<FrameName>Tab<N>"), so tabs are
-- named after the parent frame.
function Navigation.CreateTabs(frame, tabDefinitions, onSelect)
    local frameName = frame:GetName()
    frame.Tabs = {}

    for index, definition in ipairs(tabDefinitions) do
        local tab = CreateFrame("Button", frameName .. "Tab" .. index, frame, "PanelTabButtonTemplate")
        tab:SetID(index)
        tab:SetText(definition.label)
        tab.tabKey = definition.key

        if index == 1 then
            tab:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", 11, 2)
        else
            tab:SetPoint("LEFT", frame.Tabs[index - 1], "RIGHT", 3, 0)
        end

        tab:SetScript("OnClick", function(self)
            PlaySound(SOUNDKIT.IG_CHARACTER_INFO_TAB)
            onSelect(self:GetID())
        end)

        PanelTemplates_TabResize(tab, 0)
        frame.Tabs[index] = tab
    end

    PanelTemplates_SetNumTabs(frame, #tabDefinitions)
end

--------------------------------------------------------------------------------
-- Account / Character view toggle
--------------------------------------------------------------------------------

local SCOPE_BUTTON_WIDTH = 84
local SCOPE_BUTTON_HEIGHT = 22

local ScopeToggleMethods = {}

function ScopeToggleMethods:SetSelected(scopeKey)
    for _, button in ipairs(self.buttons) do
        if button.scopeKey == scopeKey then
            button:LockHighlight()
            button:GetFontString():SetTextColor(HIGHLIGHT_FONT_COLOR:GetRGB())
        else
            button:UnlockHighlight()
            button:GetFontString():SetTextColor(NORMAL_FONT_COLOR:GetRGB())
        end
    end
end

-- Buttons are laid out right-to-left so the toggle can be anchored by its
-- right edge.
-- Also used for the item lists' Missing / Done / All filter; `labelText`
-- defaults to "View:".
function Navigation.CreateScopeToggle(parent, scopeDefinitions, onSelect, labelText)
    local toggle = CreateFrame("Frame", nil, parent)
    toggle.buttons = {}
    toggle:SetSize(#scopeDefinitions * (SCOPE_BUTTON_WIDTH + 2), SCOPE_BUTTON_HEIGHT)

    for index, definition in ipairs(scopeDefinitions) do
        local button = CreateFrame("Button", nil, toggle, "UIPanelButtonTemplate")
        button:SetSize(SCOPE_BUTTON_WIDTH, SCOPE_BUTTON_HEIGHT)
        button:SetText(definition.label)
        button.scopeKey = definition.key
        button:SetPoint("LEFT", toggle, "LEFT", (index - 1) * (SCOPE_BUTTON_WIDTH + 2), 0)

        button:SetScript("OnClick", function(self)
            PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
            onSelect(self.scopeKey)
        end)
        button:SetScript("OnEnter", function(self)
            Styles.ShowSimpleTooltip(self, definition.tooltipTitle or (definition.label .. " view"), { { text = definition.tooltip } })
        end)
        button:SetScript("OnLeave", Styles.HideTooltip)

        toggle.buttons[index] = button
    end

    toggle.Label = toggle:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    toggle.Label:SetPoint("RIGHT", toggle, "LEFT", -6, 0)
    toggle.Label:SetText(labelText or "View:")

    for name, method in pairs(ScopeToggleMethods) do
        toggle[name] = method
    end
    return toggle
end

--------------------------------------------------------------------------------
-- Scroll area: a ScrollFrame with mouse wheel and a slim slider, used by the
-- zone list (sidebar and zone picker). The caller lays content out in
-- `area.Child` and reports its height with SetContentHeight.
--------------------------------------------------------------------------------

local SCROLL_WHEEL_STEP = 40

function Navigation.CreateScrollArea(parent)
    local area = CreateFrame("Frame", nil, parent)

    local scroll = CreateFrame("ScrollFrame", nil, area)
    scroll:SetPoint("TOPLEFT")
    scroll:SetPoint("BOTTOMRIGHT", -14, 0)
    area.Scroll = scroll

    local child = CreateFrame("Frame", nil, scroll)
    child:SetSize(1, 1)
    scroll:SetScrollChild(child)
    scroll:SetScript("OnSizeChanged", function(_, width)
        child:SetWidth(width)
    end)
    area.Child = child

    local slider = CreateFrame("Slider", nil, area)
    slider:SetOrientation("VERTICAL")
    slider:SetWidth(12)
    slider:SetPoint("TOPRIGHT", 0, -2)
    slider:SetPoint("BOTTOMRIGHT", 0, 2)
    slider:SetThumbTexture("Interface\\Buttons\\UI-ScrollBar-Knob")
    slider:GetThumbTexture():SetSize(16, 22)
    slider:SetMinMaxValues(0, 0)
    slider:SetValueStep(1)
    local track = slider:CreateTexture(nil, "BACKGROUND")
    track:SetColorTexture(0, 0, 0, 0.35)
    track:SetPoint("TOP")
    track:SetPoint("BOTTOM")
    track:SetWidth(4)
    slider:SetScript("OnValueChanged", function(_, value)
        scroll:SetVerticalScroll(value)
    end)
    area.Slider = slider

    area.contentHeight = 0

    function area:GetMaxScroll()
        local visible = scroll:GetHeight() or 0
        return math.max(0, self.contentHeight - visible)
    end

    function area:SetContentHeight(height)
        self.contentHeight = height
        child:SetHeight(math.max(1, height))
        local maxScroll = self:GetMaxScroll()
        slider:SetMinMaxValues(0, maxScroll)
        slider:SetShown(maxScroll > 0)
        if (slider:GetValue() or 0) > maxScroll then
            slider:SetValue(maxScroll)
        end
    end

    -- Scrolls just enough to show the band [top, top + height] of the content.
    function area:ScrollIntoView(top, height)
        local visible = scroll:GetHeight() or 0
        local current = slider:GetValue() or 0
        if top < current then
            slider:SetValue(top)
        elseif top + height > current + visible then
            slider:SetValue(math.min(self:GetMaxScroll(), top + height - visible))
        end
    end

    area:EnableMouseWheel(true)
    area:SetScript("OnMouseWheel", function(self, delta)
        local value = (slider:GetValue() or 0) - delta * SCROLL_WHEEL_STEP
        slider:SetValue(math.max(0, math.min(self:GetMaxScroll(), value)))
    end)
    return area
end

--------------------------------------------------------------------------------
-- Zone list: continents (collapsible) and their zones, scrollable.
--------------------------------------------------------------------------------

local ZONE_BUTTON_HEIGHT = 30
local HEADER_HEIGHT = 26
local TOP_PADDING = 20

local FACTION_ICONS = {
    [1] = "Interface\\FriendsFrame\\PlusManz-Horde",
    [2] = "Interface\\FriendsFrame\\PlusManz-Alliance",
}
local FACTION_NAMES = { [1] = "Horde", [2] = "Alliance" }

local function ZoneButton_OnEnter(button)
    local lines = {
        { text = Styles.FormatPercent(button.completion) .. " complete" },
    }
    if button.faction then
        lines[#lines + 1] = { text = FACTION_NAMES[button.faction] .. " zone", color = NORMAL_FONT_COLOR }
    end
    Styles.ShowSimpleTooltip(button, button.zoneName, lines)
end

local function CreateZoneButton(list)
    local button = CreateFrame("Button", nil, list.Area.Child)
    button:SetHeight(ZONE_BUTTON_HEIGHT)

    button.Selected = button:CreateTexture(nil, "BACKGROUND")
    button.Selected:SetAllPoints()
    if not Styles.SetAtlasOrFile(button.Selected, "PetList-ButtonSelect", Styles.Textures.listSelected) then
        button.Selected:SetBlendMode("ADD") -- the fallback file is meant to be drawn additively
    end
    button.Selected:Hide()

    button:SetHighlightTexture(Styles.Textures.listHighlight, "ADD")
    button:GetHighlightTexture():SetAlpha(0.5)

    button.Percent = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.Percent:SetPoint("TOPRIGHT", -8, -5)

    button.Faction = button:CreateTexture(nil, "ARTWORK")
    button.Faction:SetSize(14, 14)
    button.Faction:SetPoint("RIGHT", button.Percent, "LEFT", -4, 0)

    button.Name = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    button.Name:SetPoint("TOPLEFT", 12, -5)
    button.Name:SetPoint("TOPRIGHT", button, "TOPRIGHT", -66, -5)
    button.Name:SetJustifyH("LEFT")
    button.Name:SetWordWrap(false)

    button.Bar = Styles.CreateProgressBar(button, 3, false)
    button.Bar:SetPoint("BOTTOMLEFT", 12, 5)
    button.Bar:SetPoint("BOTTOMRIGHT", -8, 5)

    button:SetScript("OnClick", function(self)
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
        list.onZoneSelected(self.zoneID)
    end)
    button:SetScript("OnEnter", ZoneButton_OnEnter)
    button:SetScript("OnLeave", Styles.HideTooltip)
    return button
end

local function CreateHeader(list)
    local header = CreateFrame("Button", nil, list.Area.Child)
    header:SetHeight(HEADER_HEIGHT)

    header.Toggle = header:CreateTexture(nil, "ARTWORK")
    header.Toggle:SetSize(14, 14)
    header.Toggle:SetPoint("LEFT", 6, 1)

    header.Count = header:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    header.Count:SetPoint("RIGHT", -8, 0)

    -- Ends before the zone count so long names ("Eastern Kingdoms") never
    -- run into it.
    header.Text = header:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    header.Text:SetPoint("LEFT", header.Toggle, "RIGHT", 4, 0)
    header.Text:SetPoint("RIGHT", header.Count, "LEFT", -6, 0)
    header.Text:SetJustifyH("LEFT")
    header.Text:SetWordWrap(false)

    header.Divider = Styles.CreateDivider(header)
    header.Divider:SetPoint("BOTTOMLEFT", 4, -2)
    header.Divider:SetPoint("BOTTOMRIGHT", -4, -2)

    header:SetHighlightTexture(Styles.Textures.listHighlight, "ADD")
    header:GetHighlightTexture():SetAlpha(0.25)

    header:SetScript("OnClick", function(self)
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
        local opening = list.collapsed[self.continentID]
        list.collapsed[self.continentID] = not opening or nil
        list:SetSections(list.lastSections)
        if opening and list.onExpand then
            list.onExpand(self.continentID)
        end
    end)
    return header
end

local ZoneListMethods = {}

-- sections: array of { continent = { id, name },
--                      zones = { { id, name, completion, faction } } }
function ZoneListMethods:SetSections(sections)
    self.lastSections = sections
    local y = -TOP_PADDING
    local headerIndex, buttonIndex = 0, 0
    self.buttonTops = {}

    for _, section in ipairs(sections) do
        headerIndex = headerIndex + 1
        local header = self.headers[headerIndex] or CreateHeader(self)
        self.headers[headerIndex] = header
        local collapsed = self.collapsed[section.continent.id]
        header.continentID = section.continent.id
        header.Text:SetText(section.continent.name)
        header.Count:SetText(#section.zones .. " zones")
        header.Toggle:SetTexture(collapsed and "Interface\\Buttons\\UI-PlusButton-Up" or "Interface\\Buttons\\UI-MinusButton-Up")
        header:ClearAllPoints()
        header:SetPoint("TOPLEFT", 0, y)
        header:SetPoint("TOPRIGHT", 0, y)
        header:Show()
        y = y - HEADER_HEIGHT - 4

        if not collapsed then
            for _, zone in ipairs(section.zones) do
                buttonIndex = buttonIndex + 1
                local button = self.buttons[buttonIndex] or CreateZoneButton(self)
                self.buttons[buttonIndex] = button

                button.zoneID = zone.id
                button.zoneName = zone.name
                button.completion = zone.completion
                button.faction = zone.faction
                button.Name:SetText(zone.name)
                button.Percent:SetText(Styles.FormatPercent(zone.completion))
                button.Percent:SetTextColor(Styles.PercentColor(zone.completion))
                button.Faction:SetTexture(FACTION_ICONS[zone.faction])
                button.Faction:SetShown(zone.faction ~= nil)
                Styles.SetBarFraction(button.Bar, zone.completion and zone.completion / 100)

                button:ClearAllPoints()
                button:SetPoint("TOPLEFT", 0, y)
                button:SetPoint("TOPRIGHT", 0, y)
                button:Show()
                self.buttonTops[zone.id] = -y
                y = y - ZONE_BUTTON_HEIGHT - 2
            end
        end
    end

    for i = headerIndex + 1, #self.headers do
        self.headers[i]:Hide()
    end
    for i = buttonIndex + 1, #self.buttons do
        self.buttons[i]:Hide()
    end

    self.Area:SetContentHeight(-y + 4)
    self:SetSelected(self.selectedZoneID)
end

function ZoneListMethods:SetSelected(zoneID)
    self.selectedZoneID = zoneID
    for _, button in ipairs(self.buttons) do
        local isSelected = button:IsShown() and button.zoneID == zoneID
        button.Selected:SetShown(isSelected)
        if isSelected then
            button.Name:SetTextColor(HIGHLIGHT_FONT_COLOR:GetRGB())
        else
            button.Name:SetTextColor(NORMAL_FONT_COLOR:GetRGB())
        end
    end
end

function ZoneListMethods:ScrollToSelected()
    local top = self.buttonTops and self.buttonTops[self.selectedZoneID]
    if top then
        self.Area:ScrollIntoView(top, ZONE_BUTTON_HEIGHT)
    end
end

-- collapsed: a table the caller keeps (e.g. in saved variables),
-- { [continentID] = true } for collapsed continents.
-- onExpand(continentID): optional, called when a continent is opened.
function Navigation.CreateZoneList(parent, onZoneSelected, collapsed, onExpand)
    local list = CreateFrame("Frame", nil, parent)
    list.onZoneSelected = onZoneSelected
    list.onExpand = onExpand
    list.collapsed = collapsed or {}
    list.headers = {}
    list.buttons = {}
    list.lastSections = {}

    list.Area = Navigation.CreateScrollArea(list)
    list.Area:SetAllPoints()

    list.SectionLabel = list.Area.Child:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    list.SectionLabel:SetPoint("TOPLEFT", 8, -6)
    list.SectionLabel:SetText("CONTINENTS")

    for name, method in pairs(ZoneListMethods) do
        list[name] = method
    end
    return list
end

--------------------------------------------------------------------------------
-- Zone picker: compact zone switcher for the item-list tabs. A button that
-- shows the current zone and opens the zone list in a popup.
--------------------------------------------------------------------------------

local PICKER_WIDTH = 230
local POPUP_WIDTH = 270
local POPUP_HEIGHT = 380

local PickerMethods = {}

function PickerMethods:SetZone(zoneName)
    self.Button:SetText(zoneName or "Choose a zone")
end

function PickerMethods:SetSections(sections, selectedZoneID)
    self.List.selectedZoneID = selectedZoneID
    self.List:SetSections(sections)
end

function Navigation.CreateZonePicker(parent, onZoneSelected, collapsed, onExpand)
    local picker = CreateFrame("Frame", nil, parent)
    picker:SetSize(PICKER_WIDTH, 24)

    local button = CreateFrame("Button", nil, picker, "UIPanelButtonTemplate")
    button:SetAllPoints()
    button.Arrow = button:CreateTexture(nil, "OVERLAY")
    button.Arrow:SetTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up")
    button.Arrow:SetSize(22, 22)
    button.Arrow:SetPoint("RIGHT", -2, 0)
    picker.Button = button

    local popup = CreateFrame("Frame", nil, picker, "BackdropTemplate")
    popup:SetFrameStrata("DIALOG")
    popup:SetSize(POPUP_WIDTH, POPUP_HEIGHT)
    popup:SetPoint("TOPLEFT", button, "BOTTOMLEFT", 0, -4)
    popup:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    popup:SetBackdropColor(0, 0, 0, 0.95)
    popup:EnableMouse(true)
    popup:Hide()
    picker.Popup = popup

    picker.List = Navigation.CreateZoneList(popup, function(zoneID)
        popup:Hide()
        onZoneSelected(zoneID)
    end, collapsed, onExpand)
    picker.List:SetPoint("TOPLEFT", 6, -6)
    picker.List:SetPoint("BOTTOMRIGHT", -6, 6)

    button:SetScript("OnClick", function()
        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
        popup:SetShown(not popup:IsShown())
        if popup:IsShown() then
            picker.List:ScrollToSelected()
        end
    end)

    -- Close on any click outside the popup (the button toggles itself).
    popup:SetScript("OnShow", function(self) self:RegisterEvent("GLOBAL_MOUSE_DOWN") end)
    popup:SetScript("OnHide", function(self) self:UnregisterEvent("GLOBAL_MOUSE_DOWN") end)
    popup:SetScript("OnEvent", function(self)
        if not self:IsMouseOver() and not button:IsMouseOver() then
            self:Hide()
        end
    end)
    picker:SetScript("OnHide", function() popup:Hide() end)

    for name, method in pairs(PickerMethods) do
        picker[name] = method
    end
    return picker
end
