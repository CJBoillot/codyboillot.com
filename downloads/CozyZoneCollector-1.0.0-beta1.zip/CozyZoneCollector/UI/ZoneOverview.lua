-- ZoneOverview: the center column of the Zones tab. Shows one zone's
-- header, overall completion and the per-category breakdown.

local _, ZC = ...

local Styles = ZC.UI.Styles

local ZoneOverview = {}
ZC.UI.ZoneOverview = ZoneOverview

local CATEGORY_ROW_HEIGHT = 32
local FALLBACK_ZONE_ICON = "Interface\\Icons\\INV_Misc_Map_01"

local OverviewMethods = {}

local COMPLETION_LABELS = {
    account = "Account Completion",
    character = "Character Completion",
}

-- data: provider zone data (see Providers/Provider.lua); continentName: string.
function OverviewMethods:SetZone(data, continentName)
    if not data then
        self.Title:SetText("No zone selected")
        self.Subtitle:SetText("")
        self.Percent:SetText("")
        Styles.SetBarFraction(self.CompletionBar, nil)
        self.Categories:SetValues(nil, false)
        self.Footer:SetText("")
        self.ExclusionSummary:SetText("")
        return
    end

    self.Icon:SetTexture(data.icon or FALLBACK_ZONE_ICON)
    self.Title:SetText(data.name)
    self.Subtitle:SetText(continentName or "")

    self.Percent:SetText(Styles.FormatPercent(data.completion))
    self.Percent:SetTextColor(Styles.PercentColor(data.completion))
    Styles.SetBarFraction(self.CompletionBar, data.completion and data.completion / 100)

    self.CompletionLabel:SetText(COMPLETION_LABELS[data.scope] or "Zone Completion")
    self.Categories:SetValues(data.categories, data.isMock, data.scope)

    self.Footer:SetText(self:GetFooterText(data))
    self.ExclusionSummary:SetText(self:GetExclusionText(data))
    self.ExclusionHover.excluded = data.excluded
end

-- One short line saying how much the totals leave out; hovering it shows
-- the per-reason breakdown for the whole zone.
function OverviewMethods:GetExclusionText(data)
    local total = 0
    for _, count in pairs(data.excluded or {}) do
        total = total + count
    end
    if total == 0 then
        return ""
    end
    return string.format("%d things not counted  |cff808080(hover for why)|r", total)
end

local function ExclusionSummary_OnEnter(frame)
    local lines = {}
    Styles.AddExclusionLines(lines, frame.excluded)
    table.remove(lines, 1) -- drop the spacer; this tooltip starts with it
    table.remove(lines, 1) -- and the heading; it's the tooltip title
    if ZC:IsEligibleOnly() then
        lines[#lines + 1] = { text = " " }
        lines[#lines + 1] = {
            text = "Untick \"Only count what this character can do\" to include other classes, races, faction, professions, holidays and breadcrumbs.",
            color = GRAY_FONT_COLOR,
        }
    end
    Styles.ShowSimpleTooltip(frame, "Not counted in this zone", lines)
end

function OverviewMethods:GetFooterText(data)
    if data.statusText then
        return data.statusText
    elseif data.isMock then
        if data.hasDetail then
            return "Development mock data - these are not real zone totals."
        end
        return "Detailed tracking for this zone is not available yet."
    elseif data.trackedCount < #self.Categories.rows then
        return string.format("Tracking %d of %d categories - the rest are coming soon.",
            data.trackedCount, #self.Categories.rows)
    end
    return ""
end

function ZoneOverview.Create(parent)
    local panel = CreateFrame("Frame", nil, parent)

    -- Header: zone icon, name, continent.
    panel.Icon = panel:CreateTexture(nil, "ARTWORK")
    panel.Icon:SetSize(46, 46)
    panel.Icon:SetPoint("TOPLEFT", 18, -16)
    panel.Icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    panel.IconBorder = panel:CreateTexture(nil, "OVERLAY")
    panel.IconBorder:SetTexture("Interface\\Buttons\\UI-Quickslot2")
    -- Same proportions as an action button's 66px frame around a 36px icon.
    panel.IconBorder:SetSize(84, 84)
    panel.IconBorder:SetPoint("CENTER", panel.Icon, "CENTER", 0, 0)

    panel.Title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    panel.Title:SetPoint("TOPLEFT", panel.Icon, "TOPRIGHT", 14, -4)
    panel.Title:SetJustifyH("LEFT")

    panel.Subtitle = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    panel.Subtitle:SetPoint("TOPLEFT", panel.Title, "BOTTOMLEFT", 0, -6)

    -- Overall completion.
    panel.CompletionLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    panel.CompletionLabel:SetPoint("TOPLEFT", 20, -86)
    panel.CompletionLabel:SetText("Zone Completion")

    panel.Percent = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    panel.Percent:SetPoint("BOTTOMRIGHT", panel, "TOPRIGHT", -20, -100)
    panel.Percent:SetJustifyH("RIGHT")

    panel.CompletionBar = Styles.CreateProgressBar(panel, 16, false)
    panel.CompletionBar:SetPoint("TOPLEFT", 20, -108)
    panel.CompletionBar:SetPoint("TOPRIGHT", -20, -108)

    panel.Divider = Styles.CreateDivider(panel)
    panel.Divider:SetPoint("TOPLEFT", 12, -136)
    panel.Divider:SetPoint("TOPRIGHT", -12, -136)

    -- Category breakdown.
    panel.Categories = ZC.UI.CollectionList.Create(panel, ZC:GetProvider():GetCategories(), {
        valueFormat = "count",
        rowHeight = CATEGORY_ROW_HEIGHT,
    })
    panel.Categories:SetPoint("TOPLEFT", 12, -148)
    panel.Categories:SetPoint("TOPRIGHT", -12, -148)

    panel.Footer = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    panel.Footer:SetPoint("BOTTOM", 0, 10)

    panel.ExclusionSummary = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    panel.ExclusionSummary:SetPoint("BOTTOM", 0, 26)

    -- Invisible hover area over the summary line for its breakdown tooltip.
    panel.ExclusionHover = CreateFrame("Frame", nil, panel)
    panel.ExclusionHover:SetPoint("TOPLEFT", panel.ExclusionSummary, "TOPLEFT", -4, 3)
    panel.ExclusionHover:SetPoint("BOTTOMRIGHT", panel.ExclusionSummary, "BOTTOMRIGHT", 4, -3)
    panel.ExclusionHover:EnableMouse(true)
    panel.ExclusionHover:SetScript("OnEnter", ExclusionSummary_OnEnter)
    panel.ExclusionHover:SetScript("OnLeave", Styles.HideTooltip)

    for name, method in pairs(OverviewMethods) do
        panel[name] = method
    end
    return panel
end
